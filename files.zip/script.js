/* ============================================================
   HRMS – Employee Management System
   script.js  |  Logic, Validation, Navigation, Storage
   ============================================================ */

'use strict';

/* ============================================================
   STEP CONFIGURATION
   ============================================================ */
const STEPS = [
  { id:0,  title:'Dashboard',          icon:'fa-gauge-high'      },
  { id:1,  title:'Personal Info',      icon:'fa-user'            },
  { id:2,  title:'Marital Status',     icon:'fa-heart'           },
  { id:3,  title:'Upload Photo',       icon:'fa-camera'          },
  { id:4,  title:'Passport',           icon:'fa-passport'        },
  { id:5,  title:'Driving License',    icon:'fa-car'             },
  { id:6,  title:'Medical Data',       icon:'fa-heart-pulse'     },
  { id:7,  title:'Language Skills',    icon:'fa-language'        },
  { id:8,  title:'Core Skills',        icon:'fa-brain'           },
  { id:9,  title:'Membership',         icon:'fa-id-badge'        },
  { id:10, title:'Contact Address',    icon:'fa-location-dot'    },
  { id:11, title:'Emergency Contact',  icon:'fa-phone-volume'    },
  { id:12, title:'Family Info',        icon:'fa-people-roof'     },
  { id:13, title:'Academic Qualification', icon:'fa-graduation-cap' },
  { id:14, title:'Other Courses',      icon:'fa-book-open'       },
  { id:15, title:'Certifications',     icon:'fa-certificate'     },
  { id:16, title:'Achievements',       icon:'fa-trophy'          },
  { id:17, title:'Bank Info',          icon:'fa-building-columns'},
  { id:18, title:'Identification',     icon:'fa-fingerprint'     },
  { id:19, title:'Previous Employment',icon:'fa-briefcase'       },
  { id:20, title:'Summary',            icon:'fa-clipboard-check' },
];

/* ============================================================
   STATE
   ============================================================ */
let currentStep = 0;
const completedSteps = new Set();
let photoDataURL = '';
let skills = [];
let languages = [];
let memberships = [];
let emergencyContacts = [];
let familyMembers = [];
let academics = [];
let courses = [];
let certifications = [];
let achievements = [];
let employments = [];

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  buildSidebar();
  setupDropZone();
  setupTheme();
  restoreAllData();
  renderLanguageList();
  renderSkillTags();
  renderMemberships();
  renderEmergencyContacts();
  renderFamilyMembers();
  renderAcademics();
  renderCourses();
  renderCertifications();
  renderAchievements();
  renderEmployments();
  showStep(0);
  updateDashboard();

  // Mobile sidebar
  const mobileBtn = document.createElement('button');
  mobileBtn.className = 'mobile-sidebar-btn';
  mobileBtn.innerHTML = '<i class="fa-solid fa-bars"></i>';
  mobileBtn.onclick = toggleMobileSidebar;
  document.body.appendChild(mobileBtn);

  const backdrop = document.createElement('div');
  backdrop.className = 'sidebar-backdrop';
  backdrop.id = 'sidebarBackdrop';
  backdrop.onclick = toggleMobileSidebar;
  document.body.appendChild(backdrop);

  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('collapsed');
  });

  document.getElementById('saveBtn').addEventListener('click', () => {
    saveCurrentStep();
    showToast('Progress saved!', 'success');
  });

  // Auto-save on input
  document.addEventListener('input', debounce(() => {
    saveCurrentStep();
  }, 800));

  document.addEventListener('change', () => {
    saveCurrentStep();
  });

  // IFSC uppercase
  const ifscInput = document.getElementById('bank_ifsc');
  if (ifscInput) ifscInput.addEventListener('input', e => { e.target.value = e.target.value.toUpperCase(); });
  const panInput = document.getElementById('id_pan');
  if (panInput) panInput.addEventListener('input', e => { e.target.value = e.target.value.toUpperCase(); });
});

/* ============================================================
   SIDEBAR
   ============================================================ */
function buildSidebar() {
  const nav = document.getElementById('sidebarNav');
  nav.innerHTML = '';
  STEPS.forEach(step => {
    const item = document.createElement('div');
    item.className = 'step-item';
    item.dataset.step = step.id;
    item.innerHTML = `
      <div class="step-num">${step.id === 0 ? '<i class="fa-solid fa-house" style="font-size:.55rem"></i>' : step.id}</div>
      <span>${step.title}</span>
      <span class="step-check" id="stepCheck_${step.id}"></span>
    `;
    item.addEventListener('click', () => {
      if (step.id === 0 || step.id <= currentStep + 1 || completedSteps.has(step.id - 1)) {
        saveCurrentStep();
        goToStep(step.id);
      } else {
        showToast('Please complete previous steps first.', 'warning');
      }
    });
    nav.appendChild(item);
  });
}

function updateSidebar() {
  STEPS.forEach(step => {
    const item = document.querySelector(`[data-step="${step.id}"]`);
    const check = document.getElementById(`stepCheck_${step.id}`);
    if (!item) return;
    item.classList.remove('active', 'completed');
    if (step.id === currentStep) {
      item.classList.add('active');
      if (check) check.innerHTML = '';
    } else if (completedSteps.has(step.id) || step.id === 0) {
      item.classList.add('completed');
      if (check) check.innerHTML = '<i class="fa-solid fa-check"></i>';
    } else {
      if (check) check.innerHTML = '';
    }
  });
}

/* ============================================================
   NAVIGATION
   ============================================================ */
function showStep(stepId) {
  document.querySelectorAll('.step-section').forEach(s => s.classList.remove('active'));
  const target = document.querySelector(`[data-step="${stepId}"]`);
  if (target && target.classList.contains('step-section')) {
    target.classList.add('active');
  }
  currentStep = stepId;
  updateSidebar();
  updateProgressBar();
  updateNavButtons();
  if (stepId === 0) updateDashboard();
  if (stepId === 20) buildSummary();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  document.getElementById('mainContent').scrollTo({ top: 0, behavior: 'smooth' });
}

function goToStep(id) {
  showStep(id);
}

function nextStep() {
  if (currentStep >= STEPS.length - 1) return;
  if (!validateStep(currentStep)) return;
  saveCurrentStep();
  completedSteps.add(currentStep);
  updateCompletionRing();
  showStep(currentStep + 1);
}

function prevStep() {
  if (currentStep <= 0) return;
  saveCurrentStep();
  showStep(currentStep - 1);
}

function updateNavButtons() {
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const indicator = document.getElementById('stepIndicator');
  if (currentStep === 0) {
    prevBtn.style.display = 'none';
    nextBtn.style.display = 'none';
  } else if (currentStep === 20) {
    prevBtn.style.display = 'flex';
    nextBtn.style.display = 'none';
  } else {
    prevBtn.style.display = currentStep > 0 ? 'flex' : 'none';
    nextBtn.style.display = 'flex';
    nextBtn.innerHTML = currentStep === 19 ? 'Review & Submit <i class="fa-solid fa-chevron-right ms-2"></i>' : 'Next <i class="fa-solid fa-chevron-right ms-2"></i>';
  }
  if (indicator) {
    indicator.textContent = currentStep > 0 ? `Step ${currentStep} of ${STEPS.length - 2}` : '';
  }
}

function updateProgressBar() {
  const totalSteps = STEPS.length - 2; // exclude dashboard and summary
  const pct = currentStep === 0 ? 0 : Math.min(100, Math.round(((currentStep - 1) / totalSteps) * 100));
  document.getElementById('navProgressFill').style.width = pct + '%';
  const step = STEPS[currentStep];
  document.getElementById('navProgressLabel').textContent = step ? step.title : '';
}

/* ============================================================
   VALIDATION
   ============================================================ */
const validators = {
  required: (val) => val.trim() !== '' ? null : 'This field is required.',
  alpha: (val) => val.trim() === '' || /^[a-zA-Z\s'-]+$/.test(val.trim()) ? null : 'Only letters allowed.',
  email: (val) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim()) ? null : 'Enter a valid email address.',
  phone: (val) => /^[+\d\s\-().]{7,15}$/.test(val.trim()) ? null : 'Enter a valid phone number.',
  'phone-optional': (val) => val.trim() === '' || /^[+\d\s\-().]{7,15}$/.test(val.trim()) ? null : 'Enter a valid phone number.',
  pin: (val) => /^\d{6}$/.test(val.trim()) ? null : 'Enter a valid 6-digit PIN code.',
  ifsc: (val) => /^[A-Z]{4}0[A-Z0-9]{6}$/.test(val.trim().toUpperCase()) ? null : 'Enter a valid IFSC code (e.g. SBIN0001234).',
  aadhaar: (val) => /^\d{12}$/.test(val.trim()) ? null : 'Enter a valid 12-digit Aadhaar number.',
  pan: (val) => /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(val.trim().toUpperCase()) ? null : 'Enter a valid PAN (e.g. ABCDE1234F).',
};

function validateField(input) {
  const validate = input.dataset.validate;
  if (!validate) return true;
  const rules = validate.split('|');
  const val = input.value;
  for (const rule of rules) {
    if (rule === 'required-if-married') {
      const status = document.getElementById('ms_status');
      if (status && status.value === 'Married' && val.trim() === '') {
        setFieldError(input, 'Spouse name is required when married.');
        return false;
      }
      clearFieldError(input);
      return true;
    }
    if (rule === 'required-if-passport') {
      const has = document.getElementById('pp_has');
      if (has && has.value === 'Yes' && val.trim() === '') {
        setFieldError(input, 'This field is required for passport holders.');
        return false;
      }
      clearFieldError(input);
      return true;
    }
    if (rule === 'required-if-dl') {
      const has = document.getElementById('dl_has');
      if (has && has.value === 'Yes' && val.trim() === '') {
        setFieldError(input, 'This field is required for license holders.');
        return false;
      }
      clearFieldError(input);
      return true;
    }
    const fn = validators[rule];
    if (fn) {
      const err = fn(val);
      if (err) { setFieldError(input, err); return false; }
    }
  }
  clearFieldError(input);
  return true;
}

function setFieldError(input, msg) {
  input.classList.add('invalid');
  input.classList.remove('valid');
  const errEl = document.getElementById('err_' + input.id);
  if (errEl) errEl.textContent = msg;
}

function clearFieldError(input) {
  input.classList.remove('invalid');
  if (input.value.trim()) input.classList.add('valid');
  const errEl = document.getElementById('err_' + input.id);
  if (errEl) errEl.textContent = '';
}

function validateStep(stepId) {
  const section = document.querySelector(`.step-section[data-step="${stepId}"]`);
  if (!section) return true;
  const inputs = section.querySelectorAll('[data-validate]');
  let valid = true;
  inputs.forEach(input => {
    if (!validateField(input)) valid = false;
  });
  // Special validations
  if (stepId === 17) {
    const acc = document.getElementById('bank_accNo').value;
    const accC = document.getElementById('bank_accNoConfirm').value;
    if (acc && accC && acc !== accC) {
      setFieldError(document.getElementById('bank_accNoConfirm'), 'Account numbers do not match.');
      valid = false;
    }
  }
  if (!valid) {
    showToast('Please fix the errors before continuing.', 'error');
    const firstErr = section.querySelector('.invalid');
    if (firstErr) firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  return valid;
}

/* ============================================================
   TOGGLE FUNCTIONS
   ============================================================ */
function toggleSpouse() {
  const status = document.getElementById('ms_status').value;
  const section = document.getElementById('spouseSection');
  section.style.display = (status === 'Married') ? 'block' : 'none';
}

function togglePassport(val) {
  document.getElementById('pp_has').value = val;
  document.getElementById('passportFields').style.display = val === 'Yes' ? 'block' : 'none';
  document.querySelectorAll('[data-target="pp_has"]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.val === val);
  });
}

function toggleDL(val) {
  document.getElementById('dl_has').value = val;
  document.getElementById('dlFields').style.display = val === 'Yes' ? 'block' : 'none';
  document.querySelectorAll('[data-target="dl_has"]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.val === val);
  });
}

// Generic toggle button click handler
document.addEventListener('click', (e) => {
  const btn = e.target.closest('.toggle-btn[data-target]');
  if (!btn) return;
  const targetId = btn.dataset.target;
  const val = btn.dataset.val;
  const target = document.getElementById(targetId);
  if (target && !btn.onclick) {
    target.value = val;
    btn.closest('.toggle-group').querySelectorAll('.toggle-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.val === val);
    });
  }
});

/* ============================================================
   PHOTO UPLOAD
   ============================================================ */
function setupDropZone() {
  const dz = document.getElementById('dropZone');
  if (!dz) return;
  dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('dragover'); });
  dz.addEventListener('dragleave', () => dz.classList.remove('dragover'));
  dz.addEventListener('drop', e => {
    e.preventDefault(); dz.classList.remove('dragover');
    const file = e.dataTransfer.files[0];
    if (file) processPhoto(file);
  });
}

function handlePhoto(event) {
  const file = event.target.files[0];
  if (file) processPhoto(file);
}

function processPhoto(file) {
  if (!file.type.startsWith('image/')) {
    showToast('Please upload a valid image file.', 'error');
    return;
  }
  if (file.size > 2 * 1024 * 1024) {
    showToast('Image size must be under 2MB.', 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = (e) => {
    photoDataURL = e.target.result;
    showPhotoPreview(photoDataURL);
    sessionStorage.setItem('hrms_photo', photoDataURL);
    updateNavAvatar(photoDataURL);
    showToast('Photo uploaded successfully!', 'success');
  };
  reader.readAsDataURL(file);
}

function showPhotoPreview(src) {
  const img = document.getElementById('photoPreviewImg');
  const placeholder = document.getElementById('photoPlaceholder');
  const removeBtn = document.getElementById('removePhotoBtn');
  img.src = src;
  img.style.display = 'block';
  placeholder.style.display = 'none';
  if (removeBtn) removeBtn.style.display = 'inline-flex';
}

function removePhoto() {
  photoDataURL = '';
  sessionStorage.removeItem('hrms_photo');
  const img = document.getElementById('photoPreviewImg');
  const placeholder = document.getElementById('photoPlaceholder');
  const removeBtn = document.getElementById('removePhotoBtn');
  img.src = '';
  img.style.display = 'none';
  placeholder.style.display = 'flex';
  if (removeBtn) removeBtn.style.display = 'none';
  document.getElementById('photoInput').value = '';
  updateNavAvatar(null);
}

function updateNavAvatar(src) {
  const navAvatar = document.getElementById('navAvatar');
  const navAvatarPlaceholder = document.getElementById('navAvatarPlaceholder');
  if (src) {
    navAvatar.src = src;
    navAvatar.style.display = 'block';
    navAvatarPlaceholder.style.display = 'none';
    // Update dashboard photo
    const dashPhoto = document.getElementById('dashboardPhoto');
    if (dashPhoto) dashPhoto.innerHTML = `<img src="${src}" style="width:100%;height:100%;object-fit:cover;border-radius:50%"/>`;
  } else {
    navAvatar.style.display = 'none';
    navAvatarPlaceholder.style.display = 'flex';
    const dashPhoto = document.getElementById('dashboardPhoto');
    if (dashPhoto) dashPhoto.innerHTML = '<i class="fa-solid fa-user fa-3x"></i>';
  }
}

/* ============================================================
   ADDRESS COPY
   ============================================================ */
function copySameAddress() {
  const checked = document.getElementById('sameAsPerm').checked;
  const fields = ['line1','line2','city','state','pin'];
  if (checked) {
    fields.forEach(f => {
      const permVal = document.getElementById('perm_' + f)?.value || '';
      const currEl = document.getElementById('curr_' + f);
      if (currEl) currEl.value = permVal;
    });
    document.getElementById('currentAddressFields').style.opacity = '0.6';
    document.getElementById('currentAddressFields').style.pointerEvents = 'none';
  } else {
    document.getElementById('currentAddressFields').style.opacity = '1';
    document.getElementById('currentAddressFields').style.pointerEvents = 'auto';
  }
}

/* ============================================================
   DYNAMIC LISTS
   ============================================================ */

// --- LANGUAGES ---
function addLanguage(data = {}) {
  languages.push({
    id: Date.now(),
    language: data.language || '',
    read: data.read || false,
    write: data.write || false,
    speak: data.speak || false,
    proficiency: data.proficiency || 'Beginner',
  });
  renderLanguageList();
}

function renderLanguageList() {
  const container = document.getElementById('languageList');
  if (!container) return;
  if (languages.length === 0) {
    container.innerHTML = `<div class="text-muted small p-3 text-center">No languages added yet. Click "Add Language" to add one.</div>`;
    return;
  }
  container.innerHTML = languages.map((lang, idx) => `
    <div class="dynamic-item" id="lang_${lang.id}">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-3">
            <label class="form-label-hrms">Language</label>
            <input type="text" class="form-control-hrms" value="${esc(lang.language)}" 
              onchange="updateLang(${idx},'language',this.value)" placeholder="e.g. Tamil" />
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Proficiency</label>
            <select class="form-control-hrms" onchange="updateLang(${idx},'proficiency',this.value)">
              ${['Beginner','Elementary','Intermediate','Upper Intermediate','Advanced','Native'].map(p => 
                `<option ${lang.proficiency === p ? 'selected' : ''}>${p}</option>`).join('')}
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label-hrms">Skills</label>
            <div class="d-flex gap-3 mt-1">
              ${['Read','Write','Speak'].map(s => `
                <label class="checkbox-hrms">
                  <input type="checkbox" ${lang[s.toLowerCase()] ? 'checked' : ''} 
                    onchange="updateLang(${idx},'${s.toLowerCase()}',this.checked)" />
                  <span>${s}</span>
                </label>
              `).join('')}
            </div>
          </div>
          <div class="col-12">
            <div class="d-flex align-items-center gap-2">
              <span class="lang-proficiency-label">${lang.proficiency}</span>
              <div class="proficiency-bar">
                <div class="proficiency-fill" style="width:${getProficiencyPct(lang.proficiency)}%"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="removeLang(${idx})" title="Remove"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

function updateLang(idx, key, val) {
  if (languages[idx]) { languages[idx][key] = val; saveCurrentStep(); }
  if (key === 'proficiency') renderLanguageList();
}

function removeLang(idx) { languages.splice(idx, 1); renderLanguageList(); saveCurrentStep(); }

function getProficiencyPct(p) {
  const map = { Beginner:10, Elementary:25, Intermediate:50, 'Upper Intermediate':65, Advanced:85, Native:100 };
  return map[p] || 10;
}

// --- SKILLS ---
function addSkill() {
  const input = document.getElementById('skillInput');
  const cat = document.getElementById('skillCategory');
  const val = input.value.trim();
  if (!val) { showToast('Enter a skill name.', 'warning'); return; }
  if (skills.some(s => s.name.toLowerCase() === val.toLowerCase())) {
    showToast('Skill already added.', 'warning'); return;
  }
  skills.push({ name: val, category: cat.value });
  input.value = '';
  renderSkillTags();
  saveCurrentStep();
}

function removeSkill(idx) {
  skills.splice(idx, 1);
  renderSkillTags();
  saveCurrentStep();
}

function renderSkillTags() {
  const container = document.getElementById('skillTags');
  if (!container) return;
  if (skills.length === 0) {
    container.innerHTML = '<span class="text-muted small">No skills added yet.</span>';
    return;
  }
  container.innerHTML = skills.map((s, i) => `
    <span class="skill-tag tag-${s.category.toLowerCase().replace(/\s/g, '-')}">
      ${esc(s.name)}
      <button class="tag-remove" onclick="removeSkill(${i})" title="Remove">×</button>
    </span>
  `).join('');
}

// --- MEMBERSHIPS ---
function addMembership(data = {}) {
  memberships.push({ id: Date.now(), org: data.org || '', role: data.role || '', since: data.since || '' });
  renderMemberships();
}

function renderMemberships() {
  const c = document.getElementById('membershipList');
  if (!c) return;
  if (memberships.length === 0) {
    c.innerHTML = `<div class="text-muted small p-3 text-center">No memberships added.</div>`; return;
  }
  c.innerHTML = memberships.map((m, i) => `
    <div class="dynamic-item">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-5">
            <label class="form-label-hrms">Organization</label>
            <input class="form-control-hrms" value="${esc(m.org)}" onchange="memberships[${i}].org=this.value;saveCurrentStep()" placeholder="Organization name" />
          </div>
          <div class="col-md-4">
            <label class="form-label-hrms">Role / Position</label>
            <input class="form-control-hrms" value="${esc(m.role)}" onchange="memberships[${i}].role=this.value;saveCurrentStep()" placeholder="Member / Fellow" />
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Member Since</label>
            <input type="date" class="form-control-hrms" value="${esc(m.since)}" onchange="memberships[${i}].since=this.value;saveCurrentStep()" />
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="memberships.splice(${i},1);renderMemberships();saveCurrentStep()"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

// --- EMERGENCY CONTACTS ---
function addEmergencyContact(data = {}) {
  emergencyContacts.push({ id: Date.now(), name: data.name || '', rel: data.rel || '', phone: data.phone || '', email: data.email || '' });
  renderEmergencyContacts();
}

function renderEmergencyContacts() {
  const c = document.getElementById('emergencyList');
  if (!c) return;
  if (emergencyContacts.length === 0) {
    c.innerHTML = `<div class="text-muted small p-3 text-center">No emergency contacts added.</div>`; return;
  }
  c.innerHTML = emergencyContacts.map((ec, i) => `
    <div class="dynamic-item">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-3">
            <label class="form-label-hrms">Full Name <span class="req">*</span></label>
            <input class="form-control-hrms" value="${esc(ec.name)}" onchange="emergencyContacts[${i}].name=this.value;saveCurrentStep()" placeholder="Name" />
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Relationship</label>
            <select class="form-control-hrms" onchange="emergencyContacts[${i}].rel=this.value;saveCurrentStep()">
              ${['','Father','Mother','Spouse','Sibling','Friend','Other'].map(r => `<option ${ec.rel===r?'selected':''}>${r}</option>`).join('')}
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Phone <span class="req">*</span></label>
            <input type="tel" class="form-control-hrms" value="${esc(ec.phone)}" onchange="emergencyContacts[${i}].phone=this.value;saveCurrentStep()" placeholder="+91 9876543210" />
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Email</label>
            <input type="email" class="form-control-hrms" value="${esc(ec.email)}" onchange="emergencyContacts[${i}].email=this.value;saveCurrentStep()" placeholder="email@example.com" />
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="emergencyContacts.splice(${i},1);renderEmergencyContacts();saveCurrentStep()"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

// --- FAMILY MEMBERS ---
function addFamilyMember(data = {}) {
  familyMembers.push({ id: Date.now(), name: data.name || '', rel: data.rel || '', dob: data.dob || '', occupation: data.occupation || '' });
  renderFamilyMembers();
}

function renderFamilyMembers() {
  const c = document.getElementById('familyList');
  if (!c) return;
  if (familyMembers.length === 0) {
    c.innerHTML = `<div class="text-muted small p-3 text-center">No family members added.</div>`; return;
  }
  c.innerHTML = familyMembers.map((fm, i) => `
    <div class="dynamic-item">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-3">
            <label class="form-label-hrms">Name</label>
            <input class="form-control-hrms" value="${esc(fm.name)}" onchange="familyMembers[${i}].name=this.value;saveCurrentStep()" placeholder="Full name" />
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Relationship</label>
            <select class="form-control-hrms" onchange="familyMembers[${i}].rel=this.value;saveCurrentStep()">
              ${['','Father','Mother','Spouse','Son','Daughter','Brother','Sister','Other'].map(r => `<option ${fm.rel===r?'selected':''}>${r}</option>`).join('')}
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Date of Birth</label>
            <input type="date" class="form-control-hrms" value="${esc(fm.dob)}" onchange="familyMembers[${i}].dob=this.value;saveCurrentStep()" />
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Occupation</label>
            <input class="form-control-hrms" value="${esc(fm.occupation)}" onchange="familyMembers[${i}].occupation=this.value;saveCurrentStep()" placeholder="Occupation" />
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="familyMembers.splice(${i},1);renderFamilyMembers();saveCurrentStep()"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

// --- ACADEMICS ---
function addAcademic(data = {}) {
  academics.push({ id: Date.now(), degree: data.degree || '', institution: data.institution || '', board: data.board || '', year: data.year || '', grade: data.grade || '' });
  renderAcademics();
}

function renderAcademics() {
  const c = document.getElementById('academicList');
  if (!c) return;
  if (academics.length === 0) {
    c.innerHTML = `<div class="text-muted small p-3 text-center">No education records added.</div>`; return;
  }
  c.innerHTML = academics.map((a, i) => `
    <div class="dynamic-item">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-3">
            <label class="form-label-hrms">Degree / Qualification</label>
            <select class="form-control-hrms" onchange="academics[${i}].degree=this.value;saveCurrentStep()">
              ${['','High School','Diploma','B.Sc','B.E/B.Tech','B.Com','B.A','MBA','M.Sc','M.E/M.Tech','MCA','PhD','Post Doctoral','Other'].map(d => `<option ${a.degree===d?'selected':''}>${d}</option>`).join('')}
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label-hrms">Institution / University</label>
            <input class="form-control-hrms" value="${esc(a.institution)}" onchange="academics[${i}].institution=this.value;saveCurrentStep()" placeholder="College / University name" />
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">Year of Passing</label>
            <input type="number" class="form-control-hrms" value="${esc(a.year)}" onchange="academics[${i}].year=this.value;saveCurrentStep()" placeholder="YYYY" min="1950" max="2030" />
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Grade / % / CGPA</label>
            <input class="form-control-hrms" value="${esc(a.grade)}" onchange="academics[${i}].grade=this.value;saveCurrentStep()" placeholder="e.g. 85% / 8.5 CGPA" />
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="academics.splice(${i},1);renderAcademics();saveCurrentStep()"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

// --- COURSES ---
function addCourse(data = {}) {
  courses.push({ id: Date.now(), name: data.name || '', provider: data.provider || '', year: data.year || '', duration: data.duration || '' });
  renderCourses();
}

function renderCourses() {
  const c = document.getElementById('courseList');
  if (!c) return;
  if (courses.length === 0) {
    c.innerHTML = `<div class="text-muted small p-3 text-center">No courses added.</div>`; return;
  }
  c.innerHTML = courses.map((co, i) => `
    <div class="dynamic-item">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-4">
            <label class="form-label-hrms">Course Name</label>
            <input class="form-control-hrms" value="${esc(co.name)}" onchange="courses[${i}].name=this.value;saveCurrentStep()" placeholder="Course name" />
          </div>
          <div class="col-md-4">
            <label class="form-label-hrms">Provider / Institute</label>
            <input class="form-control-hrms" value="${esc(co.provider)}" onchange="courses[${i}].provider=this.value;saveCurrentStep()" placeholder="Provider name" />
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">Year</label>
            <input type="number" class="form-control-hrms" value="${esc(co.year)}" onchange="courses[${i}].year=this.value;saveCurrentStep()" placeholder="YYYY" />
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">Duration</label>
            <input class="form-control-hrms" value="${esc(co.duration)}" onchange="courses[${i}].duration=this.value;saveCurrentStep()" placeholder="e.g. 3 months" />
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="courses.splice(${i},1);renderCourses();saveCurrentStep()"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

// --- CERTIFICATIONS ---
function addCertification(data = {}) {
  certifications.push({ id: Date.now(), name: data.name || '', authority: data.authority || '', date: data.date || '', expiry: data.expiry || '' });
  renderCertifications();
}

function renderCertifications() {
  const c = document.getElementById('certList');
  if (!c) return;
  if (certifications.length === 0) {
    c.innerHTML = `<div class="text-muted small p-3 text-center">No certifications added.</div>`; return;
  }
  c.innerHTML = certifications.map((cert, i) => `
    <div class="dynamic-item">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-4">
            <label class="form-label-hrms">Certification Name</label>
            <input class="form-control-hrms" value="${esc(cert.name)}" onchange="certifications[${i}].name=this.value;saveCurrentStep()" placeholder="e.g. AWS Solutions Architect" />
          </div>
          <div class="col-md-4">
            <label class="form-label-hrms">Issuing Authority</label>
            <input class="form-control-hrms" value="${esc(cert.authority)}" onchange="certifications[${i}].authority=this.value;saveCurrentStep()" placeholder="e.g. Amazon, Microsoft, Google" />
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">Issue Date</label>
            <input type="date" class="form-control-hrms" value="${esc(cert.date)}" onchange="certifications[${i}].date=this.value;saveCurrentStep()" />
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">Expiry Date</label>
            <input type="date" class="form-control-hrms" value="${esc(cert.expiry)}" onchange="certifications[${i}].expiry=this.value;saveCurrentStep()" />
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="certifications.splice(${i},1);renderCertifications();saveCurrentStep()"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

// --- ACHIEVEMENTS ---
function addAchievement(data = {}) {
  achievements.push({ id: Date.now(), title: data.title || '', type: data.type || 'Award', year: data.year || '', description: data.description || '' });
  renderAchievements();
}

function renderAchievements() {
  const c = document.getElementById('achievementList');
  if (!c) return;
  if (achievements.length === 0) {
    c.innerHTML = `<div class="text-muted small p-3 text-center">No achievements added.</div>`; return;
  }
  c.innerHTML = achievements.map((a, i) => `
    <div class="dynamic-item">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-4">
            <label class="form-label-hrms">Title / Award Name</label>
            <input class="form-control-hrms" value="${esc(a.title)}" onchange="achievements[${i}].title=this.value;saveCurrentStep()" placeholder="Award / achievement title" />
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">Type</label>
            <select class="form-control-hrms" onchange="achievements[${i}].type=this.value;saveCurrentStep()">
              ${['Award','Recognition','Publication','Patent','Other'].map(t => `<option ${a.type===t?'selected':''}>${t}</option>`).join('')}
            </select>
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">Year</label>
            <input type="number" class="form-control-hrms" value="${esc(a.year)}" onchange="achievements[${i}].year=this.value;saveCurrentStep()" placeholder="YYYY" />
          </div>
          <div class="col-md-4">
            <label class="form-label-hrms">Description</label>
            <input class="form-control-hrms" value="${esc(a.description)}" onchange="achievements[${i}].description=this.value;saveCurrentStep()" placeholder="Brief description" />
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="achievements.splice(${i},1);renderAchievements();saveCurrentStep()"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

// --- EMPLOYMENTS ---
function addEmployment(data = {}) {
  employments.push({ id: Date.now(), company: data.company || '', role: data.role || '', from: data.from || '', to: data.to || '', current: data.current || false, salary: data.salary || '', reason: data.reason || '' });
  renderEmployments();
}

function renderEmployments() {
  const c = document.getElementById('employmentList');
  if (!c) return;
  if (employments.length === 0) {
    c.innerHTML = `<div class="text-muted small p-3 text-center">No employment records added.</div>`; return;
  }
  c.innerHTML = employments.map((emp, i) => `
    <div class="dynamic-item">
      <div class="dynamic-item-body">
        <div class="row g-2">
          <div class="col-md-4">
            <label class="form-label-hrms">Company Name</label>
            <input class="form-control-hrms" value="${esc(emp.company)}" onchange="employments[${i}].company=this.value;saveCurrentStep()" placeholder="Company name" />
          </div>
          <div class="col-md-4">
            <label class="form-label-hrms">Job Title / Role</label>
            <input class="form-control-hrms" value="${esc(emp.role)}" onchange="employments[${i}].role=this.value;saveCurrentStep()" placeholder="Designation" />
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">From Date</label>
            <input type="date" class="form-control-hrms" value="${esc(emp.from)}" onchange="employments[${i}].from=this.value;saveCurrentStep()" />
          </div>
          <div class="col-md-2">
            <label class="form-label-hrms">To Date</label>
            <input type="date" class="form-control-hrms" value="${esc(emp.to)}" onchange="employments[${i}].to=this.value;saveCurrentStep()" ${emp.current?'disabled':''} />
          </div>
          <div class="col-md-3">
            <label class="checkbox-hrms mt-2">
              <input type="checkbox" ${emp.current?'checked':''} onchange="employments[${i}].current=this.checked;renderEmployments();saveCurrentStep()" />
              <span>Currently Working Here</span>
            </label>
          </div>
          <div class="col-md-3">
            <label class="form-label-hrms">Last Drawn Salary</label>
            <input class="form-control-hrms" value="${esc(emp.salary)}" onchange="employments[${i}].salary=this.value;saveCurrentStep()" placeholder="e.g. ₹6,00,000 p.a." />
          </div>
          <div class="col-md-6">
            <label class="form-label-hrms">Reason for Leaving</label>
            <input class="form-control-hrms" value="${esc(emp.reason)}" onchange="employments[${i}].reason=this.value;saveCurrentStep()" placeholder="Reason for leaving" ${emp.current?'disabled':''} />
          </div>
        </div>
      </div>
      <button class="btn-remove" onclick="employments.splice(${i},1);renderEmployments();saveCurrentStep()"><i class="fa-solid fa-times"></i></button>
    </div>
  `).join('');
}

/* ============================================================
   STORAGE
   ============================================================ */
const STORAGE_KEY = 'hrms_data_v1';

function getFormData(stepId) {
  const section = document.querySelector(`.step-section[data-step="${stepId}"]`);
  if (!section) return {};
  const data = {};
  section.querySelectorAll('[id]').forEach(el => {
    if (el.type === 'file') return;
    if (el.type === 'checkbox') data[el.id] = el.checked;
    else data[el.id] = el.value;
  });
  return data;
}

function saveCurrentStep() {
  try {
    const stored = JSON.parse(sessionStorage.getItem(STORAGE_KEY) || '{}');
    stored['step_' + currentStep] = getFormData(currentStep);
    stored.lists = { languages, skills, memberships, emergencyContacts, familyMembers, academics, courses, certifications, achievements, employments };
    stored.completedSteps = [...completedSteps];
    stored.currentStep = currentStep;
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
  } catch (e) { console.warn('Save error:', e); }
}

function restoreAllData() {
  try {
    const stored = JSON.parse(sessionStorage.getItem(STORAGE_KEY) || '{}');
    if (!stored) return;
    // Restore lists
    if (stored.lists) {
      languages = stored.lists.languages || [];
      skills = stored.lists.skills || [];
      memberships = stored.lists.memberships || [];
      emergencyContacts = stored.lists.emergencyContacts || [];
      familyMembers = stored.lists.familyMembers || [];
      academics = stored.lists.academics || [];
      courses = stored.lists.courses || [];
      certifications = stored.lists.certifications || [];
      achievements = stored.lists.achievements || [];
      employments = stored.lists.employments || [];
    }
    // Restore completed steps
    if (stored.completedSteps) stored.completedSteps.forEach(s => completedSteps.add(s));
    // Restore field values
    for (let i = 0; i <= 20; i++) {
      const stepData = stored['step_' + i];
      if (!stepData) continue;
      Object.entries(stepData).forEach(([id, val]) => {
        const el = document.getElementById(id);
        if (!el || el.type === 'file') return;
        if (el.type === 'checkbox') el.checked = val;
        else el.value = val;
      });
    }
    // Restore photo
    const photo = sessionStorage.getItem('hrms_photo');
    if (photo) {
      photoDataURL = photo;
      showPhotoPreview(photo);
      updateNavAvatar(photo);
    }
    // Restore conditional visibility
    toggleSpouse();
    const ppHas = document.getElementById('pp_has');
    if (ppHas) togglePassport(ppHas.value);
    const dlHas = document.getElementById('dl_has');
    if (dlHas) toggleDL(dlHas.value);
  } catch (e) { console.warn('Restore error:', e); }
}

/* ============================================================
   DASHBOARD
   ============================================================ */
function updateDashboard() {
  const firstName = document.getElementById('pi_firstName')?.value || '';
  const lastName  = document.getElementById('pi_lastName')?.value || '';
  const email     = document.getElementById('pi_email')?.value || '';
  const name = [firstName, lastName].filter(Boolean).join(' ') || 'New Employee';
  const dashName = document.getElementById('dashboardName');
  const dashEmail = document.getElementById('dashboardEmail');
  if (dashName) dashName.textContent = name;
  if (dashEmail) dashEmail.textContent = email || '—';
  // Stats
  const statCompletion = document.getElementById('statCompletion');
  if (statCompletion) statCompletion.textContent = Math.round((completedSteps.size / (STEPS.length - 2)) * 100) + '%';
  const statEdu = document.getElementById('statEdu');
  if (statEdu) statEdu.textContent = academics.length || '—';
  const statExp = document.getElementById('statExp');
  if (statExp) statExp.textContent = employments.length || '—';
  const statPersonal = document.getElementById('statPersonal');
  if (statPersonal) statPersonal.textContent = firstName ? 'Done' : '—';
  // Checklist
  const cl = document.getElementById('dashboardChecklist');
  if (cl) {
    const items = STEPS.slice(1, -1).map(s => {
      const done = completedSteps.has(s.id);
      return `<div class="checklist-item ${done?'done':''}" onclick="goToStep(${s.id})">
        <i class="fa-solid ${done?'fa-circle-check':'fa-circle'} ci-icon"></i>
        <span>${s.title}</span>
      </div>`;
    });
    cl.innerHTML = items.join('');
  }
}

/* ============================================================
   COMPLETION RING
   ============================================================ */
function updateCompletionRing() {
  const total = STEPS.length - 2;
  const done  = completedSteps.size;
  const pct   = Math.round((done / total) * 100);
  const circumference = 2 * Math.PI * 28; // ≈ 176
  const fill = (pct / 100) * circumference;
  const ringFill = document.getElementById('ringFill');
  if (ringFill) ringFill.setAttribute('stroke-dasharray', `${fill} ${circumference}`);
  const pctEl = document.getElementById('completionPct');
  if (pctEl) pctEl.textContent = pct + '%';
  const statCompletion = document.getElementById('statCompletion');
  if (statCompletion) statCompletion.textContent = pct + '%';
}

/* ============================================================
   SUMMARY
   ============================================================ */
function buildSummary() {
  const container = document.getElementById('summaryContent');
  if (!container) return;
  const d = (id) => document.getElementById(id)?.value || '—';
  const sections = [
    {
      title: 'Personal Information', icon: 'fa-user', stepId: 1,
      fields: [
        ['Full Name', [d('pi_title'), d('pi_firstName'), d('pi_middleName'), d('pi_lastName')].filter(v=>v&&v!=='—').join(' ')],
        ['Date of Birth', d('pi_dob')], ['Gender', d('pi_gender')],
        ['Nationality', d('pi_nationality')], ['Email', d('pi_email')],
        ['Qualification', d('pi_qualification')], ['Mother Tongue', d('pi_motherTongue')],
      ]
    },
    {
      title: 'Marital Status', icon: 'fa-heart', stepId: 2,
      fields: [['Status', d('ms_status')], ['Spouse', d('ms_spouseName')]]
    },
    {
      title: 'Passport', icon: 'fa-passport', stepId: 4,
      fields: [['Has Passport', d('pp_has')], ['Number', d('pp_number')], ['Name on Passport', d('pp_name')]]
    },
    {
      title: 'Driving License', icon: 'fa-car', stepId: 5,
      fields: [['Has License', d('dl_has')], ['Number', d('dl_number')], ['Type', d('dl_type')]]
    },
    {
      title: 'Medical Data', icon: 'fa-heart-pulse', stepId: 6,
      fields: [['Blood Group', d('med_bloodGroup')], ['Conditions', d('med_conditions')], ['Allergies', d('med_allergies')]]
    },
    {
      title: 'Languages', icon: 'fa-language', stepId: 7,
      custom: languages.length > 0 ? languages.map(l => `<div class="summary-field"><span class="summary-key">${esc(l.language)}</span><span class="summary-val">${l.proficiency} — ${[l.read&&'Read', l.write&&'Write', l.speak&&'Speak'].filter(Boolean).join(', ') || 'None'}</span></div>`).join('') : '<div class="summary-field"><span class="summary-val text-muted">No languages added</span></div>'
    },
    {
      title: 'Core Skills', icon: 'fa-brain', stepId: 8,
      custom: skills.length > 0 ? `<div class="d-flex flex-wrap gap-2">${skills.map(s => `<span class="skill-tag tag-${s.category.toLowerCase().replace(/\s/g,'-')}">${esc(s.name)}</span>`).join('')}</div>` : '<span class="text-muted small">No skills added</span>'
    },
    {
      title: 'Contact Address', icon: 'fa-location-dot', stepId: 10,
      fields: [
        ['Permanent', [d('perm_line1'), d('perm_line2'), d('perm_city'), d('perm_state'), d('perm_pin')].filter(v=>v&&v!=='—').join(', ')],
        ['Current', [d('curr_line1'), d('curr_line2'), d('curr_city'), d('curr_state'), d('curr_pin')].filter(v=>v&&v!=='—').join(', ')],
      ]
    },
    {
      title: 'Bank Information', icon: 'fa-building-columns', stepId: 17,
      fields: [['Bank', d('bank_name')], ['Account No', d('bank_accNo') !== '—' ? '••••' + d('bank_accNo').slice(-4) : '—'], ['IFSC', d('bank_ifsc')], ['Branch', d('bank_branch')]]
    },
    {
      title: 'Identification', icon: 'fa-fingerprint', stepId: 18,
      fields: [['Aadhaar', d('id_aadhaar') !== '—' ? 'XXXX-XXXX-' + d('id_aadhaar').slice(-4) : '—'], ['PAN', d('id_pan')], ['Voter ID', d('id_voterId')]]
    },
    {
      title: 'Academic Qualification', icon: 'fa-graduation-cap', stepId: 13,
      custom: academics.length > 0 ? academics.map(a => `<div class="summary-field"><span class="summary-key">${esc(a.degree)}</span><span class="summary-val">${esc(a.institution)} — ${esc(a.year)} ${a.grade ? '('+a.grade+')' : ''}</span></div>`).join('') : '<div class="summary-field"><span class="summary-val text-muted">No education records</span></div>'
    },
    {
      title: 'Previous Employment', icon: 'fa-briefcase', stepId: 19,
      custom: employments.length > 0 ? employments.map(e => `<div class="summary-field"><span class="summary-key">${esc(e.company)}</span><span class="summary-val">${esc(e.role)} (${esc(e.from)} – ${e.current ? 'Present' : esc(e.to)})</span></div>`).join('') : '<div class="summary-field"><span class="summary-val text-muted">No employment records</span></div>'
    },
  ];

  container.innerHTML = sections.map(sec => `
    <div class="summary-section">
      <div class="summary-section-header">
        <div class="summary-section-title">
          <i class="fa-solid ${sec.icon}" style="color:var(--primary)"></i> ${sec.title}
        </div>
        <button class="btn-edit-section" onclick="goToStep(${sec.stepId})">
          <i class="fa-solid fa-pen me-1"></i>Edit
        </button>
      </div>
      ${sec.custom || sec.fields.map(([k, v]) => `
        <div class="summary-field">
          <span class="summary-key">${k}</span>
          <span class="summary-val">${v || '—'}</span>
        </div>
      `).join('')}
    </div>
  `).join('');

  // Photo in summary
  if (photoDataURL) {
    const photoSection = document.createElement('div');
    photoSection.className = 'summary-section d-flex align-items-center gap-3 mb-3';
    photoSection.innerHTML = `
      <img src="${photoDataURL}" style="width:70px;height:70px;border-radius:50%;object-fit:cover;border:3px solid var(--border)" />
      <div>
        <div class="fw-600">${document.getElementById('pi_firstName')?.value || ''} ${document.getElementById('pi_lastName')?.value || ''}</div>
        <div class="text-muted small">${document.getElementById('pi_email')?.value || ''}</div>
      </div>
    `;
    container.insertBefore(photoSection, container.firstChild);
  }
}

/* ============================================================
   FORM SUBMIT
   ============================================================ */
function submitForm() {
  saveCurrentStep();
  const empId = 'EMP' + Date.now().toString().slice(-6);
  document.getElementById('generatedEmpId').textContent = empId;
  document.getElementById('successModal').style.display = 'flex';
  showToast('Profile submitted successfully!', 'success');
}

function resetForm() {
  if (!confirm('This will clear all entered data. Continue?')) return;
  sessionStorage.clear();
  location.reload();
}

/* ============================================================
   TOAST NOTIFICATIONS
   ============================================================ */
function showToast(msg, type = 'info') {
  const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', warning: 'fa-triangle-exclamation', info: 'fa-circle-info' };
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `hrms-toast ${type}`;
  toast.innerHTML = `<i class="fa-solid ${icons[type]||icons.info} toast-icon"></i><span class="toast-msg">${msg}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'fadeOut .3s ease forwards';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

/* ============================================================
   THEME
   ============================================================ */
function setupTheme() {
  const btn = document.getElementById('themeToggle');
  const saved = localStorage.getItem('hrms_theme') || 'light';
  applyTheme(saved);
  btn.addEventListener('click', () => {
    const current = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(current);
    localStorage.setItem('hrms_theme', current);
  });
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const btn = document.getElementById('themeToggle');
  if (btn) btn.innerHTML = theme === 'dark' ? '<i class="fa-regular fa-moon"></i>' : '<i class="fa-regular fa-sun"></i>';
}

/* ============================================================
   MOBILE SIDEBAR
   ============================================================ */
function toggleMobileSidebar() {
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebarBackdrop');
  sidebar.classList.toggle('mobile-open');
  backdrop.classList.toggle('show');
}

/* ============================================================
   UTILITIES
   ============================================================ */
function esc(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function debounce(fn, delay) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
}
