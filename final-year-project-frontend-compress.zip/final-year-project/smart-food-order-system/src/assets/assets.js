import pazza from './pzza.jpg'
import salad from './salad.jpg'
import pasta from './pasta.jpg'

export const assets = {
    pazza,
    salad,
    pasta
}

export const menu_list = [
    {
        menu_name: "Pizza",
        menu_image: pazza
    },
    {
        menu_name: "Salad",
        menu_image: salad
    },
    {
        menu_name: "Pasta",
        menu_image: pasta
    }
]