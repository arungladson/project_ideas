import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/user/Homepage.jsx";
import AddCart from "./pages/admin/manageUser/AddCart.jsx";
import AdminDashboardpage from "./pages/admin/AdminDashboardpage.jsx";
import AdminMenuPage from "./pages/admin/manageUser/pages/AdminMenuPage.jsx";
import ManageRestaurant from "./pages/admin/manageResturant/ManageRestaurant.jsx"

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/addcart" element={<AddCart />} />
        <Route path="/admindashboard" element={<AdminDashboardpage />} />
        <Route path="/admin/order" element={<AdminMenuPage />} />
        <Route path="/admin/manage-restaurants" element={<ManageRestaurant />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
