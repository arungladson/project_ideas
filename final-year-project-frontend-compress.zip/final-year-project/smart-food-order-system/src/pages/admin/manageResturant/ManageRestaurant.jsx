import React, { useState } from 'react';
import Sidebar from './Restaurant/Dashboard/Sidebar';
import Navbar from './Restaurant/Dashboard/Navbar';
import RestaurantList from './Restaurant/RestaurantList';
import "../manageResturant/styles/dashboard.css";

const ManageRestaurant = () => {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="mrd-dashboard-container">
      {/* Sidebar Layout */}
      <Sidebar />

      {/* Main Content Area */}
      <main className="mrd-main-content">
        <Navbar
          onSearchChange={setSearchQuery}
          searchQuery={searchQuery}
        />

        <div className="mrd-page-wrapper">
          <RestaurantList searchQuery={searchQuery} />
        </div>
      </main>
    </div>
  );
};

export default ManageRestaurant;
