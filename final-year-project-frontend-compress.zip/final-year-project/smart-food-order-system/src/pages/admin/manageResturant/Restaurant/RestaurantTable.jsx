import React from 'react';
import { FiStar, FiEdit2, FiTrash2, FiExternalLink } from 'react-icons/fi';

const RestaurantTable = ({ restaurants }) => {
  return (
    <div className="mrd-table-container">
      <table className="mrd-table">
        <thead>
          <tr>
            <th>Resturant Name</th>
            <th>Category</th>
            <th>Rating</th>
            <th>Delivery Time</th>
            <th>Price Range</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {restaurants.map((res) => (
            <tr key={res.id}>
              <td>
                <div className="mrd-table-name-group">
                  <img src={res.image} alt={res.name} className="mrd-table-img" />
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <span style={{ fontWeight: 600 }}>{res.name}</span>
                    <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{res.location}</span>
                  </div>
                </div>
              </td>
              <td>{res.category}</td>
              <td>
                <div className="mrd-rating" style={{ width: 'fit-content' }}>
                  <FiStar fill="white" size={10} />
                  {res.rating}
                </div>
              </td>
              <td style={{ color: '#64748b' }}>{res.deliveryTime}</td>
              <td>{res.priceRange}</td>
              <td>
                <span className={`mrd-status-badge ${res.status === 'Open' ? 'mrd-status-open' : 'mrd-status-closed'}`} style={{ position: 'static' }}>
                  {res.status}
                </span>
              </td>
              <td>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="mrd-btn-icon" title="View Profile">
                    <FiExternalLink size={16} />
                  </button>
                  <button className="mrd-btn-icon" title="Edit">
                    <FiEdit2 size={16} />
                  </button>
                  <button className="mrd-btn-icon delete" title="Delete">
                    <FiTrash2 size={16} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RestaurantTable;
