import React, { useState, useMemo } from 'react';
import { restaurants, restaurantCategories } from '../../../../configure/resturant/restaurantData';
import RestaurantCard from './RestaurantCard';
import RestaurantTable from './RestaurantTable';
import { FiGrid, FiList, FiPlus } from 'react-icons/fi';
import ResturantAdd from './ResturantAdd';

const RestaurantList = ({ searchQuery }) => {
  const [view, setView] = useState('grid');
  const [category, setCategory] = useState('All');
  const [sortBy, setSortBy] = useState('name');
  const [isAddOpen, setIsAddOpen] = useState(false);

  const filteredRestaurants = useMemo(() => {
    let result = restaurants.filter((res) => {
      const matchesSearch = res.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = category === 'All' || res.category === category;
      return matchesSearch && matchesCategory;
    });

    if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'name') {
      result.sort((a, b) => a.name.localeCompare(b.name));
    }

    return result;
  }, [searchQuery, category, sortBy]);

  return (
    <div className="mrd-list-container">
      <div className="mrd-header-row">
        <div className="mrd-title-group">
          <h1>Manage Restaurants</h1>
          <p>View and manage all registered restaurant partners.</p>
        </div>
        <button className="mrd-btn-primary" onClick={() => setIsAddOpen(true)}>
          <FiPlus /> Add Restaurant
        </button>
      </div>

      <div className="mrd-controls-row">
        <div className="mrd-filter-group">
          <select
            className="mrd-select"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            {restaurantCategories.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <select
            className="mrd-select"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="name">Sort by: Name</option>
            <option value="rating">Sort by: Rating (High to Low)</option>
          </select>
        </div>

        <div className="mrd-view-toggle">
          <button
            className={`mrd-toggle-btn ${view === 'grid' ? 'active' : ''}`}
            onClick={() => setView('grid')}
          >
            <FiGrid size={16} /> Grid
          </button>
          <button
            className={`mrd-toggle-btn ${view === 'table' ? 'active' : ''}`}
            onClick={() => setView('table')}
          >
            <FiList size={16} /> Table
          </button>
        </div>
      </div>

      <div className="mrd-content-area">
        {view === 'grid' ? (
          <div className="mrd-restaurant-grid">
            {filteredRestaurants.map((res) => (
              <RestaurantCard key={res.id} restaurant={res} />
            ))}
          </div>
        ) : (
          <RestaurantTable restaurants={filteredRestaurants} />
        )}

        {filteredRestaurants.length === 0 && (
          <div style={{ textAlign: 'center', padding: '4rem', color: '#64748b' }}>
            <h2>No restaurants found</h2>
            <p>Try adjusting your search or filters.</p>
          </div>
        )}
      </div>

      {isAddOpen && (
        <ResturantAdd onClose={() => setIsAddOpen(false)} />
      )}
    </div>
  );
};

export default RestaurantList;
