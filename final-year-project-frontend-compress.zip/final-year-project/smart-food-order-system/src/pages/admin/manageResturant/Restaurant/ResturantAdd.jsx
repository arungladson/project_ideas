import React, { useState } from 'react';
import { FiImage, FiX, FiClock, FiMapPin, FiDollarSign, FiLayers, FiPlus, FiEdit2, FiTrash2 } from 'react-icons/fi';
import '../../manageUser/styles/ManageMenu.css';

const ResturantAdd = ({ onAdd, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    rating: '',
    deliveryTime: '',
    priceRange: '',
    location: '',
    status: 'Open',
    imageUrl: ''
  });

  const [errors, setErrors] = useState({});
  const [showCategoryManager, setShowCategoryManager] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };



  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.category) newErrors.category = 'Category is required';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    if (onAdd) {
      onAdd(formData);
    }
    onClose();
  };

  return (
    <>
      <div className="mm-modal-overlay" onClick={onClose}>
      <div className="mm-modal" onClick={e => e.stopPropagation()}>
        <div className="mm-modal-header">
          <h2 className="mm-modal-title">Add New Restaurant</h2>
          <button className="mm-modal-close" onClick={onClose}>
            <FiX />
          </button>
        </div>

        <form className="mm-form" onSubmit={handleSubmit}>
          {/* Image Preview */}
          <div className="mm-form-group">
            <label className="mm-form-label">Image Preview</label>
            <div className="mm-img-preview">
              {formData.imageUrl ? (
                <img src={formData.imageUrl} alt="Preview"
                  onError={e => { e.target.style.display = 'none'; }} />
              ) : (
                <div className="mm-img-preview-placeholder">
                  <FiImage />
                  <span>Paste image URL below to preview</span>
                </div>
              )}
            </div>
          </div>

          {/* Image URL */}
          <div className="mm-form-group">
            <label className="mm-form-label">Image URL</label>
            <input
              type="url"
              name="imageUrl"
              className="mm-form-input"
              placeholder="https://example.com/image.jpg"
              value={formData.imageUrl}
              onChange={handleChange}
            />
          </div>

          {/* Name */}
          <div className="mm-form-group">
            <label className="mm-form-label">Restaurant Name *</label>
            <input
              type="text"
              name="name"
              className="mm-form-input"
              placeholder="e.g., The Spicy Kitchen"
              value={formData.name}
              onChange={handleChange}
              style={errors.name ? { borderColor: '#ef4444' } : {}}
            />
            {errors.name && <span style={{ color: '#ef4444', fontSize: '12px' }}>{errors.name}</span>}
          </div>

          {/* Category & Status */}
          <div className="mm-form-row">
            <div className="mm-form-group">
              <label className="mm-form-label">Category *</label>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                <div style={{ flex: 1 }}>
                  <select
                    name="category"
                    className="mm-form-select"
                    value={formData.category}
                    onChange={handleChange}
                    style={errors.category ? { borderColor: '#ef4444' } : {}}
                  >
                    <option value="">Select category</option>
                    <option value="South Indian">South Indian</option>
                    <option value="North  Indian">North  Indian</option>
                  </select>
                </div>
                <button 
                  type="button" 
                  className="mm-btn-secondary" 
                  title="Manage Categories" 
                  style={{ padding: '11px', minWidth: '44px' }}
                  onClick={() => setShowCategoryManager(true)}
                >
                  <FiLayers />
                </button>
              </div>
              {errors.category && <span style={{ color: '#ef4444', fontSize: '12px' }}>{errors.category}</span>}
            </div>

            <div className="mm-form-group">
              <label className="mm-form-label">Status</label>
              <select
                name="status"
                className="mm-form-select"
                value={formData.status}
                onChange={handleChange}
              >
                <option value="Open">🟢 Open</option>
                <option value="Closed">🔴 Closed</option>
              </select>
            </div>
          </div>

          {/* Location & Delivery Time */}
          <div className="mm-form-row">
            <div className="mm-form-group">
              <label className="mm-form-label">Location</label>
              <div style={{ position: 'relative' }}>
                <FiMapPin style={{ position: 'absolute', left: '12px', top: '13px', color: '#6b7280' }} />
                <input
                  type="text"
                  name="location"
                  className="mm-form-input"
                  placeholder="e.g., Downtown"
                  value={formData.location}
                  onChange={handleChange}
                  style={{ paddingLeft: '34px' }}
                />
              </div>
            </div>
            <div className="mm-form-group">
              <label className="mm-form-label">Delivery Time</label>
              <div style={{ position: 'relative' }}>
                <FiClock style={{ position: 'absolute', left: '12px', top: '13px', color: '#6b7280' }} />
                <input
                  type="text"
                  name="deliveryTime"
                  className="mm-form-input"
                  placeholder="e.g., 30-40 mins"
                  value={formData.deliveryTime}
                  onChange={handleChange}
                  style={{ paddingLeft: '34px' }}
                />
              </div>
            </div>
          </div>

          {/* Rating & Price Range */}
          <div className="mm-form-row">
            <div className="mm-form-group">
              <label className="mm-form-label">Rating (e.g., 4.5)</label>
              <input
                type="number"
                name="rating"
                className="mm-form-input"
                placeholder="0.0"
                step="0.1"
                min="0"
                max="5"
                value={formData.rating}
                onChange={handleChange}
              />
            </div>
            <div className="mm-form-group">
              <label className="mm-form-label">Price Range</label>
              <div style={{ position: 'relative' }}>
                <FiDollarSign style={{ position: 'absolute', left: '12px', top: '13px', color: '#6b7280' }} />
                <input
                  type="text"
                  name="priceRange"
                  className="mm-form-input"
                  placeholder="e.g., $$ or ₹₹₹"
                  value={formData.priceRange}
                  onChange={handleChange}
                  style={{ paddingLeft: '34px' }}
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="mm-form-actions" style={{ marginTop: '8px' }}>
            <button type="button" className="mm-btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="mm-btn-primary">Add Restaurant</button>
          </div>
        </form>
      </div>
    </div>

      {/* Manage Categories Modal */}
      {showCategoryManager && (
        <div className="mm-modal-overlay" onClick={() => setShowCategoryManager(false)} style={{ zIndex: 1100 }}>
          <div className="mm-modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '450px' }}>
            <div className="mm-modal-header">
              <h2 className="mm-modal-title">Manage Categories</h2>
              <button type="button" className="mm-modal-close" onClick={() => setShowCategoryManager(false)}>
                <FiX />
              </button>
            </div>
            <div className="mm-form" style={{ paddingBottom: '10px' }}>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
                <input className="mm-form-input" placeholder="New category name..." type="text" value="" readOnly />
                <button type="button" className="mm-btn-primary" style={{ padding: '10px', minWidth: '44px' }}>
                  <FiPlus />
                </button>
              </div>
              <div style={{ maxHeight: '300px', overflowY: 'auto', border: '1px solid #e5e7eb', borderRadius: '12px' }}>
                <ul style={{ listStyle: 'none', padding: '0px', margin: '0px' }}>
                  <li style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #f3f4f6' }}>
                    <span style={{ fontSize: '14px', fontWeight: '500', color: '#374151' }}>South Indian</span>
                    <div style={{ display: 'flex', gap: '4px' }}>
                      <button type="button" className="mm-btn-edit" style={{ padding: '6px' }}>
                        <FiEdit2 size={14} />
                      </button>
                      <button type="button" className="mm-btn-danger" style={{ padding: '6px' }}>
                        <FiTrash2 size={14} />
                      </button>
                    </div>
                  </li>
                  <li style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #f3f4f6' }}>
                    <span style={{ fontSize: '14px', fontWeight: '500', color: '#374151' }}>North Indian</span>
                    <div style={{ display: 'flex', gap: '4px' }}>
                      <button type="button" className="mm-btn-edit" style={{ padding: '6px' }}>
                        <FiEdit2 size={14} />
                      </button>
                      <button type="button" className="mm-btn-danger" style={{ padding: '6px' }}>
                        <FiTrash2 size={14} />
                      </button>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div className="mm-form-actions" style={{ padding: '0px 28px 28px' }}>
              <button type="button" className="mm-btn-secondary" style={{ width: '100%' }} onClick={() => setShowCategoryManager(false)}>Done</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ResturantAdd;
