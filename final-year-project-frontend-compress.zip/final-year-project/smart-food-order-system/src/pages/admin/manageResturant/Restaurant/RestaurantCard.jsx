import React from 'react';
import { FiStar, FiClock, FiMapPin, FiEdit2, FiTrash2 } from 'react-icons/fi';

const RestaurantCard = ({ restaurant }) => {
  return (
    <div className="mrd-card">
      <div className="mrd-card-image-wrapper">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="mrd-card-image"
        />
        <span className={`mrd-status-badge ${restaurant.status === 'Open' ? 'mrd-status-open' : 'mrd-status-closed'}`}>
          {restaurant.status}
        </span>
      </div>

      <div className="mrd-card-content">
        <div className="mrd-card-header">
          <h3 className="mrd-card-title">{restaurant.name}</h3>
          <div className="mrd-rating">
            <FiStar fill="white" size={10} />
            {restaurant.rating}
          </div>
        </div>

        <p className="mrd-category">{restaurant.category}</p>

        <div className="mrd-details">
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <FiClock size={14} />
            {restaurant.deliveryTime}
          </div>
          <div style={{ fontWeight: 600, color: '#1e293b' }}>
            {restaurant.priceRange}
          </div>
        </div>

        <div className="mrd-location">
          <FiMapPin size={14} />
          {restaurant.location}
        </div>

        <div className="mrd-card-actions">
          <button className="mrd-btn-icon" title="Edit Restaurant">
            <FiEdit2 size={16} />
          </button>
          <button className="mrd-btn-icon delete" title="Delete Restaurant">
            <FiTrash2 size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default RestaurantCard;
