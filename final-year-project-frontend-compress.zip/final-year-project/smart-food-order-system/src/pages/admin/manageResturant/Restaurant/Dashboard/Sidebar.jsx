import React from 'react';
import { 
  FiGrid, 
  FiShoppingBag, 
  FiList, 
  FiUsers, 
  FiSettings,
  FiLogOut
} from 'react-icons/fi';
import { Link, useLocation } from 'react-router-dom';

const Sidebar = () => {
  const location = useLocation();

  const menuItems = [
    { title: 'Dashboard', icon: <FiGrid />, path: '/admindashboard' },
    { title: 'Manage Restaurants', icon: <FiShoppingBag />, path: '/admin/manage-restaurants' },
    { title: 'Menu', icon: <FiList />, path: '/admin/order' },
    { title: 'Orders', icon: <FiShoppingBag />, path: '/admin/orders' },
    { title: 'Users', icon: <FiUsers />, path: '/admin/users' },
  ];

  return (
    <aside className="mrd-sidebar">
      <div className="mrd-logo">
        <FiShoppingBag />
        <span className="mrd-logo-text">SMART FOOD</span>
      </div>

      <nav className="mrd-nav">
        {menuItems.map((item, index) => (
          <Link
            key={index}
            to={item.path}
            className={`mrd-nav-item ${location.pathname === item.path ? 'active' : ''}`}
          >
            {item.icon}
            <span className="mrd-nav-text">{item.title}</span>
          </Link>
        ))}
      </nav>

      <div style={{ marginTop: 'auto' }}>
        <Link to="/settings" className="mrd-nav-item">
          <FiSettings />
          <span className="mrd-nav-text">Settings</span>
        </Link>
        <button className="mrd-nav-item" style={{ width: '100%', border: 'none', background: 'none', cursor: 'pointer' }}>
          <FiLogOut />
          <span className="mrd-nav-text">Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
