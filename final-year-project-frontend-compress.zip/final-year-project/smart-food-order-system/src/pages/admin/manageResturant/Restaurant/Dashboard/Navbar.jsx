import React from 'react';
import { FiSearch, FiBell, FiChevronDown } from 'react-icons/fi';

const Navbar = ({ onSearchChange, searchQuery }) => {
  return (
    <nav className="mrd-navbar">
      <div className="mrd-search-container">
        <FiSearch style={{ color: '#94a3b8' }} />
        <input
          type="text"
          className="mrd-search-input"
          placeholder="Search restaurants, cafes, bakeries..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>

      <div className="mrd-nav-right">
        <div className="mrd-notification-icon">
          <FiBell />
          <span className="mrd-badge">3</span>
        </div>

        <div className="mrd-profile">
          <img
            src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150&q=80"
            alt="Admin"
            className="mrd-avatar"
          />
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
            <span style={{ fontSize: '0.875rem', fontWeight: 600, color: '#1e293b' }}>Mike Admin</span>
            <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Super Admin <FiChevronDown style={{ fontSize: '0.625rem' }} /></span>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
