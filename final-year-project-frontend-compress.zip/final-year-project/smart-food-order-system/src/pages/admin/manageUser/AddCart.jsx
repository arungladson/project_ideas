import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchMenu, addMenu, deleteMenu } from "../../../configure/order/menuSlice.js";

function MenuPage() {

    const dispatch = useDispatch();
    const items = useSelector(state => state.menu.items);

    const [name, setName] = useState("");
    const [price, setPrice] = useState("");

    useEffect(() => {
        dispatch(fetchMenu());
    }, [dispatch]);

    const handleAdd = () => {
        dispatch(addMenu({
            name: name,
            price: price,
            category: "Food"
        }));

        setName("");
        setPrice("");
    };

    return (
        <div>

            <h2>Add Menu Item</h2>

            <input
                placeholder="Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
            />

            <input
                placeholder="Price"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
            />

            <button onClick={handleAdd}>
                Add
            </button>

            <h2>Menu List</h2>

            {items.map(item => (
                <div key={item.id}>
                    {item.name} - {item.price}

                    <button
                        onClick={() => dispatch(deleteMenu(item.id))}
                    >
                        Delete
                    </button>
                </div>
            ))}

        </div>
    );
}

export default MenuPage;