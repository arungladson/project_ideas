import React, { useEffect, useState, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchMenu, addMenu, updateMenu, deleteMenu } from '../../../../configure/order/menuSlice.js';
import { fetchCategory } from '../../../../configure/category/categorySlice.js';
import MenuList from '../components/MenuList.jsx';
import AddMenu from '../components/AddMenu.jsx';
import EditMenu from '../components/EditMenu.jsx';
import Toast from '../components/Toast.jsx';
import Spinner from '../components/Spinner.jsx';
import '../styles/ManageMenu.css';
import {
  FiPlus, FiSearch, FiPackage, FiDollarSign, FiLayers,
  FiAlertTriangle
} from 'react-icons/fi';

const AdminMenuPage = () => {
  const dispatch = useDispatch();
  const { items, loading } = useSelector(state => state.menu);
  const { items: categoryItems } = useSelector(state => state.category);

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [toast, setToast] = useState(null);

  useEffect(() => {
    dispatch(fetchMenu());
    dispatch(fetchCategory());
  }, [dispatch]);

  // Filtered items
  const filteredItems = useMemo(() => {
    let result = items || [];
    if (searchQuery.trim()) {
      result = result.filter(item =>
        item.name?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (selectedCategory !== 'All') {
      result = result.filter(item => item.category === selectedCategory);
    }
    return result;
  }, [items, searchQuery, selectedCategory]);

  // Stats
  const stats = useMemo(() => ({
    total: items?.length || 0,
    categories: [...new Set((items || []).map(i => i.category))].length,
    avgPrice: items?.length
      ? (items.reduce((sum, i) => sum + (i.price || 0), 0) / items.length).toFixed(2)
      : '0.00',
  }), [items]);

  const showToast = (message, type = 'success') => {
    setToast({ message, type, key: Date.now() });
  };

  // ── Handlers ────────────────────────────
  const handleAdd = async (menuItem) => {
    try {
      await dispatch(addMenu(menuItem)).unwrap();
      setShowAddModal(false);
      showToast('Menu item added successfully!');
    } catch (err) {
      showToast(typeof err === 'string' ? err : (err.message || 'Failed to add menu item'), 'error');
    }
  };

  const handleUpdate = async (id, menuItem) => {
    try {
      await dispatch(updateMenu({ id, ...menuItem })).unwrap();
      setEditingItem(null);
      showToast('Menu item updated successfully!');
    } catch (err) {
      showToast(typeof err === 'string' ? err : (err.message || 'Failed to update menu item'), 'error');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await dispatch(deleteMenu(deleteTarget.id)).unwrap();
      setDeleteTarget(null);
      showToast('Menu item deleted successfully!');
    } catch (err) {
      showToast(typeof err === 'string' ? err : (err.message || 'Failed to delete menu item'), 'error');
    }
  };

  return (
    <div className="mm-page">
      {/* Page Content */}
      <div className="mm-content">

        {/* Page Header */}
        <div className="mm-page-header">
          <h1 className="mm-page-title">
            Menu <span>Management</span>
          </h1>
          <div className="mm-header-actions">
            <button className="mm-btn-primary" onClick={() => setShowAddModal(true)}>
              <FiPlus /> Add Menu Item
            </button>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="mm-stats-bar">
          <div className="mm-stat-chip">
            <div className="mm-stat-icon green"><FiPackage /></div>
            <div className="mm-stat-info">
              <h4>{stats.total}</h4>
              <p>Total Items</p>
            </div>
          </div>
          <div className="mm-stat-chip">
            <div className="mm-stat-icon blue"><FiLayers /></div>
            <div className="mm-stat-info">
              <h4>{stats.categories}</h4>
              <p>Categories</p>
            </div>
          </div>
          <div className="mm-stat-chip">
            <div className="mm-stat-icon amber"><FiDollarSign /></div>
            <div className="mm-stat-info">
              <h4>${stats.avgPrice}</h4>
              <p>Avg. Price</p>
            </div>
          </div>
        </div>

        {/* Toolbar */}
        <div className="mm-toolbar">
          <div className="mm-toolbar-left">
            <div className="mm-search-wrapper">
              <FiSearch />
              <input
                type="text"
                className="mm-search-input"
                placeholder="Search menu items..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>
            <select
              className="mm-category-filter"
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
            >
              <option value="All">All Categories</option>
              {Array.isArray(categoryItems) && categoryItems.map(cat => (
                <option key={cat.id} value={cat.name}>{cat.name}</option>
              ))}
            </select>
          </div>
          <span style={{ fontSize: '13px', color: '#9ca3af' }}>
            Showing {filteredItems.length} of {items?.length || 0} items
          </span>
        </div>

        {/* Menu List */}
        {loading ? (
          <Spinner message="Loading menu items..." />
        ) : (
          <MenuList
            items={filteredItems}
            onEdit={item => setEditingItem(item)}
            onDeleteRequest={item => setDeleteTarget(item)}
          />
        )}
      </div>

     
      {/* Add Modal */}
      {showAddModal && (
        <AddMenu
          onAdd={handleAdd}
          onClose={() => setShowAddModal(false)}
        />
      )}

      {/* Edit Modal */}
      {editingItem && (
        <EditMenu
          item={editingItem}
          onUpdate={handleUpdate}
          onClose={() => setEditingItem(null)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="mm-modal-overlay" onClick={() => setDeleteTarget(null)}>
          <div className="mm-modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '420px' }}>
            <div className="mm-confirm-modal">
              <div className="mm-confirm-icon">
                <FiAlertTriangle />
              </div>
              <h3 className="mm-confirm-title">Delete Menu Item?</h3>
              <p className="mm-confirm-text">
                Are you sure you want to delete "<strong>{deleteTarget.name}</strong>"?
                This action cannot be undone.
              </p>
              <div className="mm-confirm-actions">
                <button className="mm-btn-secondary" onClick={() => setDeleteTarget(null)}>
                  Cancel
                </button>
                <button className="mm-btn-danger" onClick={handleDelete}>
                  <FiAlertTriangle /> Delete Item
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <Toast
          key={toast.key}
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
};

export default AdminMenuPage;
