import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { FiImage, FiX, FiLayers, FiStar } from 'react-icons/fi';
import CategoryManager from './CategoryManager.jsx';

// const CATEGORIES = ['Appetizer', 'Main Course', 'Dessert', 'Beverage', 'Snack', 'Fast Food', 'Biryani', 'Pizza', 'Chinese', 'South Indian'];

const EditMenu = ({ item, onUpdate, onClose }) => {
  const { items: categories, loading: categoryLoading, error: categoryError } = useSelector(state => state.category);
  const [showCatManager, setShowCatManager] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    price: '',
    imageUrl: '',
    rating: 0,
    discountPercentage: '',
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name || '',
        description: item.description || '',
        category: item.category || '',
        price: item.price?.toString() || '',
        imageUrl: item.imageUrl || '',
        rating: item.rating || 0,
        discountPercentage: item.discountPercentage?.toString() || '',
      });
    }
  }, [item]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.category) newErrors.category = 'Category is required';
    if (!formData.price || Number(formData.price) <= 0) newErrors.price = 'Valid price is required';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    onUpdate(item.id, {
      name: formData.name.trim(),
      description: formData.description.trim(),
      category: formData.category,
      price: parseFloat(formData.price),
      imageUrl: formData.imageUrl.trim(),
      rating: formData.rating?.toString() || "0",
      discountPercentage: formData.discountPercentage?.toString() || "0",
    });
  };

  return (
    <div className="mm-modal-overlay" onClick={onClose}>
      <div className="mm-modal" onClick={e => e.stopPropagation()}>
        <div className="mm-modal-header">
          <h2 className="mm-modal-title">Edit Menu Item</h2>
          <button className="mm-modal-close" onClick={onClose}>
            <FiX />
          </button>
        </div>

        <form className="mm-form" onSubmit={handleSubmit}>
          {/* Image Preview */}
          <div className="mm-form-group">
            <label className="mm-form-label">Image Preview</label>
            <div className="mm-img-preview">
              {formData.imageUrl ? (
                <img src={formData.imageUrl} alt="Preview"
                     onError={e => { e.target.style.display = 'none'; }} />
              ) : (
                <div className="mm-img-preview-placeholder">
                  <FiImage />
                  <span>Paste image URL below to preview</span>
                </div>
              )}
            </div>
          </div>

          {/* Image URL */}
          <div className="mm-form-group">
            <label className="mm-form-label">Image URL</label>
            <input
              type="url"
              name="imageUrl"
              className="mm-form-input"
              placeholder="https://example.com/image.jpg"
              value={formData.imageUrl}
              onChange={handleChange}
            />
          </div>

          {/* Name */}
          <div className="mm-form-group">
            <label className="mm-form-label">Item Name *</label>
            <input
              type="text"
              name="name"
              className="mm-form-input"
              placeholder="e.g., Chicken Biryani"
              value={formData.name}
              onChange={handleChange}
              style={errors.name ? { borderColor: '#ef4444' } : {}}
            />
            {errors.name && <span style={{ color: '#ef4444', fontSize: '12px' }}>{errors.name}</span>}
          </div>

          {/* Category & Price */}
          <div className="mm-form-row">
            <div className="mm-form-group">
              <label className="mm-form-label">Category *</label>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                <div style={{ flex: 1 }}>
                  <select
                    name="category"
                    className="mm-form-select"
                    value={formData.category}
                    onChange={handleChange}
                    style={errors.category ? { borderColor: '#ef4444' } : {}}
                  >
                    <option value="">Select category</option>
                    {Array.isArray(categories) && categories.length > 0 ? (
                      categories.map(cat => (
                        <option key={cat.id || cat.Id} value={cat.name || cat.Name}>{cat.name || cat.Name}</option>
                      ))
                    ) : (
                      <option disabled>{categoryLoading ? 'Loading...' : 'No categories found'}</option>
                    )}
                  </select>
                </div>
                <button 
                  type="button" 
                  className="mm-btn-secondary" 
                  style={{ padding: '11px', minWidth: '44px' }}
                  onClick={() => setShowCatManager(true)}
                  title="Manage Categories"
                >
                  <FiLayers />
                </button>
              </div>
              {categoryError && <div style={{ color: '#ef4444', fontSize: '11px', marginTop: '4px' }}>Error: {categoryError}</div>}
              {errors.category && <span style={{ color: '#ef4444', fontSize: '12px' }}>{errors.category}</span>}
            </div>
            <div className="mm-form-group">
              <label className="mm-form-label">Price ($) *</label>
              <input
                type="number"
                name="price"
                className="mm-form-input"
                placeholder="0.00"
                step="0.01"
                min="0"
                value={formData.price}
                onChange={handleChange}
                style={errors.price ? { borderColor: '#ef4444' } : {}}
              />
              {errors.price && <span style={{ color: '#ef4444', fontSize: '12px' }}>{errors.price}</span>}
            </div>
          </div>

          {/* Rating & Discount */}
          <div className="mm-form-row">
            <div className="mm-form-group">
              <label className="mm-form-label">Rating (1-5 Stars)</label>
              <div className="mm-star-rating-input">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    className={`mm-star-btn ${formData.rating >= star ? 'active' : ''}`}
                    onClick={() => setFormData(prev => ({ ...prev, rating: star }))}
                  >
                    <FiStar fill={formData.rating >= star ? "currentColor" : "none"} />
                  </button>
                ))}
              </div>
            </div>
            <div className="mm-form-group">
              <label className="mm-form-label">Discount (%) (Optional)</label>
              <input
                type="number"
                name="discountPercentage"
                className="mm-form-input"
                placeholder="e.g., 10"
                min="0"
                max="100"
                value={formData.discountPercentage}
                onChange={handleChange}
              />
            </div>
          </div>

          {/* Description */}
          <div className="mm-form-group">
            <label className="mm-form-label">Description</label>
            <textarea
              name="description"
              className="mm-form-textarea"
              placeholder="Describe the dish, ingredients, special notes..."
              value={formData.description}
              onChange={handleChange}
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="mm-form-actions">
            <button type="button" className="mm-btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="mm-btn-primary">Update Item</button>
          </div>
        </form>
      </div>

      {showCatManager && (
        <CategoryManager onClose={() => setShowCatManager(false)} />
      )}
    </div>
  );
};

export default EditMenu;
