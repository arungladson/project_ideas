import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { FiX, FiPlus, FiEdit2, FiTrash2, FiCheck } from 'react-icons/fi';
import { addCategory, updateCategory, deleteCategory, fetchCategory } from '../../../../configure/category/categorySlice.js';

const CategoryManager = ({ onClose }) => {
  const dispatch = useDispatch();
  const { items: categories, loading } = useSelector(state => state.category);
  
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    dispatch(fetchCategory());
  }, [dispatch]);

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;
    try {
      await dispatch(addCategory({ name: newCategoryName.trim() })).unwrap();
      setNewCategoryName('');
      setError('');
    } catch (err) {
      setError(err || 'Failed to add category');
    }
  };

  const handleUpdate = async (id) => {
    if (!editName.trim()) return;
    try {
      await dispatch(updateCategory({ id, name: editName.trim() })).unwrap();
      setEditingId(null);
      setEditName('');
      setError('');
    } catch (err) {
      setError(err || 'Failed to update category');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this category? Items in this category might become uncategorized.')) {
      try {
        await dispatch(deleteCategory(id)).unwrap();
        setError('');
      } catch (err) {
        setError(err || 'Failed to delete category');
      }
    }
  };

  return (
    <div className="mm-modal-overlay" onClick={onClose} style={{ zIndex: 1100 }}>
      <div className="mm-modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '450px' }}>
        <div className="mm-modal-header">
          <h2 className="mm-modal-title">Manage Categories</h2>
          <button className="mm-modal-close" onClick={onClose}>
            <FiX />
          </button>
        </div>

        <div className="mm-form" style={{ paddingBottom: '10px' }}>
          {error && <div style={{ color: '#ef4444', fontSize: '13px', marginBottom: '10px' }}>{error}</div>}
          
          {/* Add New Category */}
          <form onSubmit={handleAdd} style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
            <input
              type="text"
              className="mm-form-input"
              placeholder="New category name..."
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              disabled={loading}
            />
            <button type="submit" className="mm-btn-primary" style={{ padding: '10px', minWidth: '44px' }} disabled={loading}>
              <FiPlus />
            </button>
          </form>

          {/* List of Categories */}
          <div style={{ maxHeight: '300px', overflowY: 'auto', border: '1px solid #e5e7eb', borderRadius: '12px' }}>
            {categories.length === 0 ? (
              <p style={{ padding: '20px', textAlign: 'center', color: '#9ca3af', fontSize: '14px' }}>No categories found.</p>
            ) : (
              <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                {categories.map((cat) => (
                  <li key={cat.id} style={{ 
                    padding: '12px 16px', 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'space-between',
                    borderBottom: '1px solid #f3f4f6'
                  }}>
                    {editingId === cat.id ? (
                      <div style={{ display: 'flex', gap: '8px', width: '100%' }}>
                        <input
                          type="text"
                          className="mm-form-input"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          autoFocus
                        />
                        <button 
                          className="mm-btn-primary" 
                          style={{ padding: '6px 12px', background: '#0bb34c' }}
                          onClick={() => handleUpdate(cat.id)}
                        >
                          <FiCheck />
                        </button>
                        <button 
                          className="mm-btn-secondary" 
                          style={{ padding: '6px 12px' }}
                          onClick={() => setEditingId(null)}
                        >
                          <FiX />
                        </button>
                      </div>
                    ) : (
                      <>
                        <span style={{ fontSize: '14px', fontWeight: '500', color: '#374151' }}>{cat.name}</span>
                        <div style={{ display: 'flex', gap: '4px' }}>
                          <button 
                            className="mm-btn-edit" 
                            style={{ padding: '6px' }}
                            onClick={() => {
                              setEditingId(cat.id);
                              setEditName(cat.name);
                            }}
                          >
                            <FiEdit2 size={14} />
                          </button>
                          <button 
                            className="mm-btn-danger" 
                            style={{ padding: '6px' }}
                            onClick={() => handleDelete(cat.id)}
                          >
                            <FiTrash2 size={14} />
                          </button>
                        </div>
                      </>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="mm-form-actions" style={{ padding: '0 28px 28px' }}>
          <button className="mm-btn-secondary" style={{ width: '100%' }} onClick={onClose}>
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

export default CategoryManager;
