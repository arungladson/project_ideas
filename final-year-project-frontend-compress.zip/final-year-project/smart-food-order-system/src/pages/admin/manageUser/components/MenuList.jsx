import React from 'react';
import { FiEdit2, FiTrash2, FiImage, FiStar } from 'react-icons/fi';

const MenuList = ({ items, onEdit, onDeleteRequest }) => {

  if (!items || items.length === 0) {
    return (
      <div className="mm-empty">
        <FiImage />
        <h3>No menu items yet</h3>
        <p>Click "Add Menu Item" to create your first dish!</p>
      </div>
    );
  }

  return (
    <div className="mm-grid">
      {items.map((item) => (
        <div className="mm-card" key={item.id}>
          {/* Image */}
          <div className="mm-card-img-wrapper">
            {item.imageUrl ? (
              <img
                src={item.imageUrl}
                alt={item.name}
                className="mm-card-img"
                onError={e => {
                  e.target.style.display = 'none';
                  e.target.nextSibling && (e.target.nextSibling.style.display = 'flex');
                }}
              />
            ) : null}
            <div
              className="mm-card-img-placeholder"
              style={item.imageUrl ? { display: 'none' } : {}}
            >
              <FiImage />
              <span>No image</span>
            </div>
            {item.category && (
              <span className="mm-card-category-badge">{item.category}</span>
            )}
            {parseFloat(item.discountPercentage) > 0 && (
              <span className="mm-card-discount-badge">{item.discountPercentage}% OFF</span>
            )}
          </div>

          {/* Body */}
          <div className="mm-card-body">
            <h3 className="mm-card-name">{item.name}</h3>
            {parseFloat(item.rating) > 0 && (
              <div className="mm-card-rating">
                {[1, 2, 3, 4, 5].map((star) => (
                  <FiStar
                    key={star}
                    className={parseFloat(item.rating) >= star ? 'star-filled' : 'star-empty'}
                    fill={parseFloat(item.rating) >= star ? '#f59e0b' : 'none'}
                  />
                ))}
                <span>({parseFloat(item.rating).toFixed(1)})</span>
              </div>
            )}
            <p className="mm-card-desc">{item.description || 'No description available'}</p>
            <div className="mm-card-footer">
              <div className="mm-card-price-wrapper">
                {parseFloat(item.discountPercentage) > 0 ? (
                  <>

                    <span className="mm-card-price-original">
                      ₹{item.price?.toFixed(2)}
                    </span>
                    <span className="mm-card-price-discounted">
                      ₹{(item.price * (1 - parseFloat(item.discountPercentage) / 100)).toFixed(2)}
                    </span>
                  </>
                ) : (
                  <span className="mm-card-price">₹{item.price?.toFixed(2)}</span>
                )}
              </div>
              <div className="mm-card-actions">
                <button className="mm-btn-edit" onClick={() => onEdit(item)}>
                  <FiEdit2 /> Edit
                </button>
                <button className="mm-btn-danger" onClick={() => onDeleteRequest(item)}>
                  <FiTrash2 /> Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MenuList;
