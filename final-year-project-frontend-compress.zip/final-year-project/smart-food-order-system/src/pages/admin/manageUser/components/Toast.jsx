import React, { useEffect, useState } from 'react';

const Toast = ({ message, type = 'success', onClose, duration = 3000 }) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(() => onClose && onClose(), 300);
    }, duration);
    return () => clearTimeout(timer);
  }, [duration, onClose]);

  const colors = {
    success: { bg: '#05a647', icon: '✓' },
    error:   { bg: '#ef4444', icon: '✕' },
    info:    { bg: '#3b82f6', icon: 'ℹ' },
    warning: { bg: '#f59e0b', icon: '⚠' },
  };

  const { bg, icon } = colors[type] || colors.info;

  return (
    <div style={{
      position: 'fixed', top: '24px', right: '24px', zIndex: 9999,
      display: 'flex', alignItems: 'center', gap: '12px',
      background: bg, color: '#fff',
      padding: '14px 24px', borderRadius: '12px',
      boxShadow: '0 8px 32px rgba(0,0,0,0.18)',
      fontFamily: "'Inter', sans-serif", fontSize: '14px', fontWeight: 500,
      transform: isVisible ? 'translateX(0)' : 'translateX(120%)',
      opacity: isVisible ? 1 : 0,
      transition: 'all 0.3s cubic-bezier(0.25,0.8,0.25,1)',
      minWidth: '280px',
    }}>
      <span style={{
        width: '28px', height: '28px', borderRadius: '50%',
        background: 'rgba(255,255,255,0.25)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontWeight: 700, fontSize: '14px', flexShrink: 0,
      }}>{icon}</span>
      <span style={{ flex: 1 }}>{message}</span>
      <button onClick={() => { setIsVisible(false); setTimeout(() => onClose && onClose(), 300); }}
        style={{
          background: 'none', border: 'none', color: 'rgba(255,255,255,0.7)',
          cursor: 'pointer', fontSize: '18px', padding: '0 0 0 8px', lineHeight: 1,
        }}>×</button>
    </div>
  );
};

export default Toast;
