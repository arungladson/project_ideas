import React from 'react';

const Spinner = ({ message = 'Loading...' }) => {
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9998,
      background: 'rgba(255,255,255,0.7)', backdropFilter: 'blur(4px)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', gap: '16px',
    }}>
      <div style={{
        width: '48px', height: '48px',
        border: '4px solid #e5e7eb',
        borderTopColor: '#0bb34c',
        borderRadius: '50%',
        animation: 'spinnerRotate 0.8s linear infinite',
      }} />
      <span style={{
        fontFamily: "'Inter', sans-serif",
        fontSize: '14px', color: '#6b7280', fontWeight: 500,
      }}>{message}</span>

      <style>{`
        @keyframes spinnerRotate {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default Spinner;
