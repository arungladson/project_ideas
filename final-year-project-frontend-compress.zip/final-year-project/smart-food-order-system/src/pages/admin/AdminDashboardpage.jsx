import React from 'react';
import { Link } from 'react-router-dom';
import './AdminDashboardpage.css';
import {
  FiGrid, FiFileText, FiMessageSquare, FiBarChart2, FiUser,
  FiSettings, FiHelpCircle, FiSearch, FiBell, FiMoon,
  FiSliders, FiChevronDown, FiUpload, FiCalendar, FiCheck, FiRefreshCw, FiX, FiMoreVertical
} from 'react-icons/fi';

const AdminDashboardpage = () => {
  return (
    <div className="db-container">
      {/* Sidebar */}
      <aside className="db-sidebar">
        <div className="db-logo">
          SMILE FOOD
        </div>

        <div className="db-menu-section">
          <div className="db-menu-title">MAIN</div>
          <nav className="db-menu-ul">
            <Link to="/admindashboard" className="db-menu-item active">
              <FiGrid className="db-menu-icon" /> Overview
            </Link>
            <Link to="/admin/orders" className="db-menu-item">
              <FiFileText className="db-menu-icon" /> Manage
            </Link>
            <Link to="/admin/messages" className="db-menu-item">
              <FiMessageSquare className="db-menu-icon" /> Messages
            </Link>
            <Link to="/admin/statistics" className="db-menu-item">
              <FiBarChart2 className="db-menu-icon" /> Statistics
            </Link>
            <Link to="/admin/profile" className="db-menu-item">
              <FiUser className="db-menu-icon" /> Profile
            </Link>
          </nav>
        </div>

        <div className="db-menu-section">
          <div className="db-menu-title">SUPPORT</div>
          <nav className="db-menu-ul">
            <Link to="/admin/settings" className="db-menu-item">
              <FiSettings className="db-menu-icon" /> Settings
            </Link>
            <Link to="/admin/help" className="db-menu-item">
              <FiHelpCircle className="db-menu-icon" /> Help
            </Link>
            <div className="db-menu-item" style={{ cursor: 'default' }}>
              <div className="db-darkmode-toggle">
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <FiMoon className="db-menu-icon" /> Dark mode
                </div>
                <div className="db-toggle-switch"></div>
              </div>
            </div>
          </nav>
        </div>

        <div className="db-referral-card">
          <div className="db-ref-title">Earns 50 $ when<br />you refer!</div>
          <div className="db-ref-desc">Refer a friends and get a<br />bonus now!</div>
          <button className="db-ref-btn">Show more</button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="db-main">

        {/* Header */}
        <header className="db-header">
          <div className="db-greeting">Hello, Mike!</div>
          <div className="db-header-right">
            <div className="db-search-box">
              <FiSearch style={{ color: '#9ca3af', fontSize: '18px' }} />
              <input type="text" className="db-search-input" placeholder="Search anything here..." />
            </div>
            <div className="db-notification">
              <FiBell />
            </div>
            <div className="db-profile">
              <img src="https://i.pravatar.cc/150?img=11" alt="Profile" />
            </div>
          </div>
        </header>

        {/* Action Bar */}
        <div className="db-actions">
          <div className="db-actions-left">
            <button className="db-btn db-btn-filter">
              <FiSliders className="icon" /> Filters
            </button>
            <button className="db-btn db-btn-date">
              <FiCalendar className="icon" /> Last 30 days <FiChevronDown style={{ marginLeft: '4px', color: '#9ca3af' }} />
            </button>
          </div>
          <button className="db-btn db-btn-export">
            <FiUpload style={{ fontSize: '16px' }} /> Export PDF
          </button>
        </div>

        {/* Stats Row */}
        <div className="db-stats-row">
          <div className="db-stat-card">
            <div className="db-stat-left">
              <div className="db-stat-title">Monthly Delivery</div>
              <div className="db-stat-value">857 orders</div>
              <div className="db-stat-trend db-trend-down">
                <svg width="20" height="12" viewBox="0 0 20 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="2,2 8,8 14,4 18,10"></polyline>
                  <polyline points="14,10 18,10 18,6"></polyline>
                </svg>
                -10% vs past month
              </div>
            </div>
            <div className="db-stat-icon-wrapper">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="db-icon-illustration db-icon-delivery">
                <rect x="3" y="10" width="10" height="10" rx="1"></rect>
                <path d="M13 10L18 10L21 14L21 20L19 20"></path>
                <circle cx="6" cy="20" r="1.5"></circle>
                <circle cx="17" cy="20" r="1.5"></circle>
                <polyline points="13,14 18,14"></polyline>
                <polyline points="5,10 5,6 9,6 9,10"></polyline>
              </svg>
            </div>
          </div>

          <div className="db-stat-card">
            <div className="db-stat-left">
              <div className="db-stat-title">Monthly work hours</div>
              <div className="db-stat-value">158 hours</div>
              <div className="db-stat-trend db-trend-up">
                <svg width="20" height="12" viewBox="0 0 20 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="2,10 8,4 14,8 18,2"></polyline>
                  <polyline points="14,2 18,2 18,6"></polyline>
                </svg>
                +20% vs past month
              </div>
            </div>
            <div className="db-stat-icon-wrapper">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="db-icon-illustration db-icon-calendar">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
                <circle cx="15" cy="16" r="3"></circle>
                <polyline points="15,14.5 15,16 16,17"></polyline>
              </svg>
            </div>
          </div>

          <div className="db-stat-card">
            <div className="db-stat-left">
              <div className="db-stat-title">Earned funds</div>
              <div className="db-stat-value">1,5k $</div>
              <div className="db-stat-trend db-trend-up">
                <svg width="20" height="12" viewBox="0 0 20 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="2,10 8,4 14,8 18,2"></polyline>
                  <polyline points="14,2 18,2 18,6"></polyline>
                </svg>
                +5% vs past month
              </div>
            </div>
            <div className="db-stat-icon-wrapper">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="db-icon-illustration db-icon-money">
                <path d="M8 21h8a4 4 0 004-4v-5a4 4 0 00-4-4H8a4 4 0 00-4 4v5a4 4 0 004 4z"></path>
                <path d="M12 8v-4"></path>
                <path d="M10 6h4"></path>
                <circle cx="12" cy="15" r="2"></circle>
              </svg>
            </div>
          </div>
        </div>

        {/* Bottom Row */}
        <div className="db-bottom-row">

          <div className="db-card">
            <div className="db-card-header">
              <div className="db-card-title">Statistics</div>
              <a href="#" className="db-card-link">more &gt;</a>
            </div>
            <div className="db-chart-legend">
              <div className="db-legend-item">
                <div className="db-legend-label">
                  <div className="db-dot db-dot-green"></div>
                  Central area
                </div>
                <div className="db-legend-value">52%</div>
              </div>
              <div className="db-legend-item">
                <div className="db-legend-label">
                  <div className="db-dot db-dot-lightgreen"></div>
                  South - Western area
                </div>
                <div className="db-legend-value">15%</div>
              </div>
              <div className="db-legend-item">
                <div className="db-legend-label">
                  <div className="db-dot db-dot-orange"></div>
                  Eastern area
                </div>
                <div className="db-legend-value">33%</div>
              </div>
            </div>
            <div className="db-chart-container">
              <svg viewBox="0 0 160 160" width="160" height="160" style={{ transform: 'rotate(-90deg)' }}>
                <circle cx="80" cy="80" r="60" fill="none" stroke="#f3f4f6" strokeWidth="20" />
                {/* Green - 52% */}
                <circle cx="80" cy="80" r="60" fill="none" stroke="#0bb34c" strokeWidth="20" strokeLinecap="round" strokeDasharray="186 376.99" strokeDashoffset="0" />
                {/* Orange - 33% */}
                <circle cx="80" cy="80" r="60" fill="none" stroke="#f97316" strokeWidth="20" strokeLinecap="round" strokeDasharray="114 376.99" strokeDashoffset="-196" />
                {/* Light Green - 15% */}
                <circle cx="80" cy="80" r="60" fill="none" stroke="#bef264" strokeWidth="20" strokeLinecap="round" strokeDasharray="46 376.99" strokeDashoffset="-320" />
              </svg>
              <div className="db-chart-inner">
                <p>Total orders</p>
                <h4>857</h4>
              </div>
            </div>
          </div>

          <div className="db-card">
            <div className="db-card-header">
              <div className="db-card-title">Orders history</div>
              <a href="#" className="db-card-link">more &gt;</a>
            </div>
            <div className="db-table-wrapper">
              <table className="db-table">
                <thead>
                  <tr>
                    <th>Order number</th>
                    <th>Status</th>
                    <th>Date and Time</th>
                    <th>Amount</th>
                    <th>Info</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>#12345678</td>
                    <td><span className="db-status db-status-completed"><FiCheck /> Completed</span></td>
                    <td>1/10/2024 at 5:12 PM</td>
                    <td><span className="db-amount db-amount-green">$ 32,85</span></td>
                    <td><FiMoreVertical /></td>
                  </tr>
                  <tr>
                    <td>#12345677</td>
                    <td><span className="db-status db-status-pending"><FiRefreshCw /> Pending</span></td>
                    <td>1/10/2024 at 3:24 PM</td>
                    <td><span className="db-amount db-amount-green">$ 12</span></td>
                    <td><FiMoreVertical /></td>
                  </tr>
                  <tr>
                    <td>#12345676</td>
                    <td><span className="db-status db-status-failed"><FiX /> Faild</span></td>
                    <td>1/10/2024 at 1:56 PM</td>
                    <td><span className="db-amount db-amount-red">$ 21,99</span></td>
                    <td><FiMoreVertical /></td>
                  </tr>
                  <tr>
                    <td>#12345675</td>
                    <td><span className="db-status db-status-pending"><FiRefreshCw /> Pending</span></td>
                    <td>1/10/2024 at 1:17 PM</td>
                    <td><span className="db-amount db-amount-green">$ 52</span></td>
                    <td><FiMoreVertical /></td>
                  </tr>
                  <tr>
                    <td>#12345674</td>
                    <td><span className="db-status db-status-completed"><FiCheck /> Completed</span></td>
                    <td>1/10/2024 at 12:31 PM</td>
                    <td><span className="db-amount db-amount-green">$ 19,99</span></td>
                    <td><FiMoreVertical /></td>
                  </tr>
                  <tr>
                    <td>#12345673</td>
                    <td><span className="db-status db-status-completed"><FiCheck /> Completed</span></td>
                    <td>1/10/2024 at 11:29 AM</td>
                    <td><span className="db-amount db-amount-green">$ 15</span></td>
                    <td><FiMoreVertical /></td>
                  </tr>
                  <tr>
                    <td>#12345672</td>
                    <td><span className="db-status db-status-completed"><FiCheck /> Completed</span></td>
                    <td>1/10/2024 at 11:03 AM</td>
                    <td><span className="db-amount db-amount-green">$ 15</span></td>
                    <td><FiMoreVertical /></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
};

export default AdminDashboardpage;
