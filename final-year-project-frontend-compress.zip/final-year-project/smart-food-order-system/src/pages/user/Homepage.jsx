import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  FiSearch, FiMapPin, FiShoppingCart, FiUser, FiChevronRight,
  FiStar, FiClock, FiArrowRight, FiArrowLeft, FiFacebook, FiTwitter,
  FiInstagram, FiPlay, FiSmartphone, FiCheckCircle, FiTruck, FiCreditCard, FiActivity, FiImage
} from 'react-icons/fi';
import { useDispatch, useSelector } from 'react-redux';
import { fetchMenu } from '../../configure/order/menuSlice.js';
import { fetchCategory } from '../../configure/category/categorySlice.js';
import "../../style/user/Homepage.css";

// --- Mock Data ---
const RESTAURANTS = [
  { id: 1, name: 'Pizza Hut', rating: 4.2, time: '25-30 mins', cuisine: 'Pizza, Fast Food', image: '/images/restaurant_food_grid.png', badge: 'Top Rated' },
  { id: 2, name: 'Burger King', rating: 4.5, time: '20-25 mins', cuisine: 'Burgers, American', image: '/images/restaurant_food_grid.png', badge: 'Fast Delivery' },
  { id: 3, name: 'Paradise Biryani', rating: 4.8, time: '35-40 mins', cuisine: 'Biryani, Indian', image: '/images/restaurant_food_grid.png', badge: 'Must Try' },
  { id: 4, name: 'Wow! Momo', rating: 4.1, time: '15-20 mins', cuisine: 'Chinese, Snacks', image: '/images/restaurant_food_grid.png', badge: '' },
  { id: 5, name: 'Starbucks', rating: 4.6, time: '10-15 mins', cuisine: 'Coffee, Desserts', image: '/images/restaurant_food_grid.png', badge: '' },
  { id: 6, name: 'Subway', rating: 4.3, time: '20-25 mins', cuisine: 'Healthy, Salads', image: '/images/restaurant_food_grid.png', badge: 'Healthy' },
];

const OFFERS = [
  { id: 1, title: '50% OFF', desc: 'Up to $10 on your first order', color: '#FF5200' },
  { id: 2, title: 'BOGO', desc: 'Buy 1 Get 1 Free on all Pizzas', color: '#4CAF50' },
  { id: 3, title: 'Free Delivery', desc: 'No delivery fee on orders above $20', color: '#2196F3' },
  { id: 4, title: 'Weekend Special', desc: 'Extra 20% cashback using PayTM', color: '#9C27B0' },
];

const TRENDING = [
  { id: 1, name: 'Grilled Chicken', price: 12.99, image: '/images/trending_dishes.png' },
  { id: 2, name: 'Salmon Poke Bowl', price: 15.50, image: '/images/trending_dishes.png' },
  { id: 3, name: 'Chocolate Lava', price: 6.99, image: '/images/trending_dishes.png' },
  { id: 4, name: 'Mango Smoothie', price: 5.50, image: '/images/trending_dishes.png' },
];

const TESTIMONIALS = [
  { id: 1, name: 'John Doe', text: 'The delivery was super fast and the food was still hot when it arrived. Amazing service!', rating: 5, img: 'https://i.pravatar.cc/150?img=1' },
  { id: 2, name: 'Sarah Smith', text: 'I love the variety of restaurants available. Ordering is so easy and the app is very smooth.', rating: 4, img: 'https://i.pravatar.cc/150?img=5' },
  { id: 3, name: 'Mike Johnson', text: 'Best food delivery app I have ever used. The live tracking is very accurate.', rating: 5, img: 'https://i.pravatar.cc/150?img=11' },
];

const CATEGORY_ICONS = {
  'Pizza': '🍕',
  'Burger': '🍔',
  'Biryani': '🍛',
  'Desserts': '🍰',
  'Drinks': '🧋',
  'Sushi': '🍣',
  'Chinese': '🥡',
  'Healthy': '🥗',
};

const placeholders = [
  "Search for restaurant, cuisine or a dish...",
  "Order your favorite Pizza",
  "Craving some Biryani?",
  "Healthy salads delivered fast"
];

export default function Homepage() {
  const dispatch = useDispatch();
  const scrollRef = useRef(null);
  const { items: menuItems, loading: menuLoading } = useSelector(state => state.menu);
  const { items: categories, loading: categoryLoading } = useSelector(state => state.category);

  const [scrolled, setScrolled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [placeholderIndex, setPlaceholderIndex] = useState(0);

  const dynamicPlaceholders = [
    "milk", "bread", "sugar", "butter", "paneer",
    "chocolate", "curd", "rice", "egg", "chips"
  ];

  useEffect(() => {
    dispatch(fetchMenu());
    dispatch(fetchCategory());

    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);

    const interval = setInterval(() => {
      setPlaceholderIndex((prev) => (prev + 1) % dynamicPlaceholders.length);
    }, 3000);

    // Initial load simulation
    setTimeout(() => setLoading(false), 800);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearInterval(interval);
    };
  }, [dispatch]);

  const scroll = (direction) => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth * 0.7 : scrollLeft + clientWidth * 0.7;
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  // Derive dynamic categories with images from menu items
  const dynamicCategories = useMemo(() => {
    if (!categories || categories.length === 0) return [];

    return categories.map(cat => {
      // Find the first menu item in this category that has an image
      const itemWithImage = menuItems?.find(item =>
        item.category?.toLowerCase() === cat.name?.toLowerCase() && item.imageUrl
      );

      return {
        id: cat.id,
        name: cat.name,
        image: itemWithImage?.imageUrl || null,
        icon: CATEGORY_ICONS[cat.name] || '🥘' // Fallback icon
      };
    });
  }, [categories, menuItems]);

  return (
    <div className="home-wrapper">
      {/* ── Navbar ────────────────────────── */}
      <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
        <Link to="/" className="nav-brand">
          <FiActivity className="logo-icon" />
          <span className="logo-text">SFSS</span>
        </Link>

        <div className="nav-search-container">
          <div className="search-bar">
            <FiSearch size={18} color="#9ca3af" />
            <input type="text" placeholder={`Search for ${dynamicPlaceholders[placeholderIndex]}`} />
          </div>
        </div>

        <div className="location-selector">
          <FiMapPin color="#FF5200" />
          <span>New York, USA</span>
        </div>

        <ul className="nav-links">
          <li><Link to="/" className="nav-link">Home</Link></li>
          <li><Link to="/restaurants" className="nav-link">Restaurants</Link></li>
          <li><Link to="/offers" className="nav-link">Offers</Link></li>
          <li className="cart-btn">
            <Link to="/cart" className="nav-link"><FiShoppingCart size={20} /><span className="cart-count">3</span></Link>
          </li>
          <li><Link to="/profile" className="nav-link"><FiUser size={20} /></Link></li>
        </ul>
      </nav>

      {/* ── Hero Section ──────────────────── */}
      <section className="hero">
        <div className="hero-content">
          <h1 className="animate-up">Delicious food, delivered to your doorstep</h1>
          <p className="animate-up" style={{ animationDelay: '0.2s' }}>
            Experience the taste of luxury from the comfort of your home.
            Freshly prepared, carefully packed, and delivered with love.
          </p>
          <div className="hero-btns animate-up" style={{ animationDelay: '0.4s' }}>
            <Link to="/menu" className="btn-primary">
              Order Now <FiArrowRight />
            </Link>
            <Link to="/restaurants" className="btn-secondary">
              Explore Restaurants
            </Link>
          </div>
        </div>
      </section>


      {/* ── Categories Section ────────────── */}
      <section className="section" style={{ paddingBottom: '40px' }}>
        <div className="section-header">
          <div>
            <h2 className="section-title">What's on your mind?</h2>
          </div>
          <div className="category-scroll-btns">
            <button className="scroll-btn" onClick={() => scroll('left')}>
              <FiArrowLeft />
            </button>
            <button className="scroll-btn" onClick={() => scroll('right')}>
              <FiArrowRight />
            </button>
          </div>
        </div>

        {categoryLoading || menuLoading ? (
          <div className="category-list skeleton-list">
            {Array(8).fill(0).map((_, i) => (
              <div key={i} className="category-item skeleton" style={{ width: '150px', height: '150px', borderRadius: '50%' }}></div>
            ))}
          </div>
        ) : dynamicCategories.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px', color: '#9ca3af' }}>
            <FiImage size={40} style={{ marginBottom: '10px' }} />
            <p>No categories found yet.</p>
          </div>
        ) : (
          <div className="category-list" ref={scrollRef}>
            {dynamicCategories.map((cat, i) => (
              <div key={cat.id || i} className="category-item animate-up" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="category-icon-wrapper">
                  {cat.image ? (
                    <img
                      src={cat.image}
                      alt={cat.name}
                    />
                  ) : (
                    cat.icon
                  )}
                </div>
                <p>{cat.name}</p>
              </div>
            ))}
          </div>
        )}
        <div className="section-divider"></div>
      </section>


      {/* ── Offers & Deals ────────────────── */}
      <section className="section" style={{ backgroundColor: 'var(--bg-light)' }}>
        <div className="section-header">
          <div>
            <h2 className="section-title">Exclusive Offers</h2>
            <p className="section-subtitle">Grab the best deals of the day</p>
          </div>
        </div>

        <div className="offers-container">
          <div className="offers-list">
            {OFFERS.map(offer => (
              <div key={offer.id} className="offer-card">
                <div className="offer-bg"></div>
                <div className="offer-content">
                  <h3 className="offer-title">{offer.title}</h3>
                  <p className="offer-desc">{offer.desc}</p>
                  <button className="btn-secondary" style={{ marginTop: '20px', padding: '10px 20px', fontSize: '13px' }}>
                    Redeem Code
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Popular Restaurants ───────────── */}
      <section className="section">
        <div className="section-header">
          <div>
            <h2 className="section-title">Top Rated Restaurants</h2>
            <p className="section-subtitle">The most loved places in your area</p>
          </div>
          <Link to="/restaurants" className="nav-link" style={{ fontSize: '14px' }}>
            View More <FiChevronRight />
          </Link>
        </div>

        <div className="restaurant-grid">
          {loading ? (
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="restaurant-card skeleton" style={{ height: '320px' }}></div>
            ))
          ) : (
            RESTAURANTS.map(res => (
              <div key={res.id} className="restaurant-card">
                <div className="res-img-wrapper">
                  {res.badge && <span className="res-badge">{res.badge}</span>}
                  <img src={res.image} alt={res.name} />
                </div>
                <div className="res-info">
                  <div className="res-name-row">
                    <h3 className="res-name">{res.name}</h3>
                    <div className="res-rating"><FiStar size={12} fill="white" /> {res.rating}</div>
                  </div>
                  <p style={{ color: 'var(--text-light)', fontSize: '14px' }}>{res.cuisine}</p>
                  <div className="res-details">
                    <div className="res-detail-item"><FiClock size={16} color="var(--primary)" /> {res.time}</div>
                    <div className="res-detail-item"><strong>$$</strong></div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      {/* ── Trending Dishes ───────────────── */}
      <section className="section">
        <div className="section-header">
          <div>
            <h2 className="section-title">Trending Dishes</h2>
            <p className="section-subtitle">People are loving these right now</p>
          </div>
        </div>

        <div className="restaurant-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))' }}>
          {menuLoading ? (
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="dish-card skeleton" style={{ height: '350px' }}></div>
            ))
          ) : menuItems && menuItems.length > 0 ? (
            menuItems.slice(0, 8).map((dish, i) => (
              <div key={dish.id || i} className="zomato-card animate-up" style={{ animationDelay: `${i * 0.1}s` }}>
                <Link to={`/dish/${dish.id}`} className="card-link">
                  <div className="img-wrapper">
                    <img src={dish.imageUrl || '/images/trending_dishes.png'} alt={dish.name} className="res-img" />
                    {dish.discountPercentage && (
                      <div className="discount-badge-overlay">
                        <p>{dish.discountPercentage}% OFF</p>
                      </div>
                    )}
                  </div>

                  <div className="res-details-container">
                    <div className="res-name-row">
                      <h4 className="res-name-text">{dish.name}</h4>
                      <div className="res-rating-container">
                        <div className="res-rating-box">
                          {dish.rating || "4.5"} <FiStar fill="#fff" size={10} />
                        </div>
                      </div>
                    </div>

                    <div className="res-info-row">
                      <p className="res-cuisine-text">{dish.category || "North Indian, South Indian"}</p>
                      <p className="res-price-text">₹{dish.price} for one</p>
                    </div>

                    <div className="res-meta-row">
                      <div className="min-info-right">
                        <p>28 min</p>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))

          ) : (
            <p style={{ textAlign: 'center', gridColumn: '1 / -1', color: 'var(--text-light)' }}>No dishes available at the moment.</p>
          )}
        </div>
      </section>

      {/* ── App Features ──────────────────── */}
      <section className="section">
        <div className="features-grid">
          <div className="feature-card">
            <FiTruck className="feature-icon" />
            <h3>Fast Delivery</h3>
            <p>Your food will be at your door within 30 minutes, guaranteed.</p>
          </div>
          <div className="feature-card">
            <FiActivity className="feature-icon" />
            <h3>Order Tracking</h3>
            <p>Track your food in real-time from the kitchen to your doorstep.</p>
          </div>
          <div className="feature-card">
            <FiCreditCard className="feature-icon" />
            <h3>Secure Payments</h3>
            <p>Multiple payment options from credit cards to digital wallets.</p>
          </div>
        </div>
      </section>

      {/* ── Testimonials ──────────────────── */}
      <section className="section" style={{ background: 'var(--bg-light)' }}>
        <h2 className="section-title" style={{ textAlign: 'center', marginBottom: '50px' }}>What our foodies say</h2>
        <div className="testimonial-container">
          {TESTIMONIALS.map(t => (
            <div key={t.id} className="testimonial-card">
              <div className="user-row">
                <img src={t.img} alt={t.name} className="user-img" />
                <div className="user-name">{t.name}</div>
              </div>
              <div className="rating-stars">
                {Array(t.rating).fill(0).map((_, i) => <FiStar key={i} fill="#ffb400" />)}
              </div>
              <p className="testimonial-text">"{t.text}"</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Footer ────────────────────────── */}
      <footer className="footer">
        <div className="footer-grid">
          <div className="footer-col">
            <Link to="/" className="footer-logo">SFSS</Link>
            <p className="footer-desc">
              Your favorite food delivered fast. We are committed to bringing you
              the best dining experience at home with the widest variety of restaurants.
            </p>
            <div className="social-links">
              <a href="#" className="social-link"><FiFacebook /></a>
              <a href="#" className="social-link"><FiTwitter /></a>
              <a href="#" className="social-link"><FiInstagram /></a>
            </div>
          </div>

          <div className="footer-col">
            <h4>Company</h4>
            <ul className="footer-links">
              <li><Link to="/about">About Us</Link></li>
              <li><Link to="/team">Our Team</Link></li>
              <li><Link to="/careers">Careers</Link></li>
              <li><Link to="/blog">Blog</Link></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Support</h4>
            <ul className="footer-links">
              <li><Link to="/help">Help Center</Link></li>
              <li><Link to="/contact">Contact Us</Link></li>
              <li><Link to="/privacy">Privacy Policy</Link></li>
              <li><Link to="/terms">Terms of Service</Link></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Experience SFSS App</h4>
            <div className="app-btns">
              <a href="#" className="app-btn">
                <FiPlay size={24} />
                <div><span>GET IT ON</span><strong>Google Play</strong></div>
              </a>
              <a href="#" className="app-btn">
                <FiSmartphone size={24} />
                <div><span>Download on the</span><strong>App Store</strong></div>
              </a>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <p>© 2026 Smart Food Service System. All rights reserved.</p>
          <div style={{ display: 'flex', gap: '30px' }}>
            <span>Privacy</span>
            <span>Terms</span>
            <span>Cookies</span>
          </div>
        </div>
      </footer>
    </div >
  );
}