export const restaurants = [
  {
    id: 1,
    name: "Spicy Hub",
    category: "South Indian",
    rating: 4.5,
    deliveryTime: "30 mins",
    priceRange: "₹200 for two",
    location: "Chennai",
    status: "Open",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 2,
    name: "Pizza World",
    category: "Fast Food",
    rating: 4.2,
    deliveryTime: "25 mins",
    priceRange: "₹300 for two",
    location: "Bangalore",
    status: "Closed",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 3,
    name: "Burger King",
    category: "Fast Food",
    rating: 4.3,
    deliveryTime: "20 mins",
    priceRange: "₹450 for two",
    location: "Mumbai",
    status: "Open",
    image: "https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 4,
    name: "The Great Kebab Factory",
    category: "North Indian",
    rating: 4.8,
    deliveryTime: "40 mins",
    priceRange: "₹800 for two",
    location: "Delhi",
    status: "Open",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 5,
    name: "Sushi Delight",
    category: "Japanese",
    rating: 4.6,
    deliveryTime: "35 mins",
    priceRange: "₹1200 for two",
    location: "Kolkata",
    status: "Open",
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 6,
    name: "Taco Time",
    category: "Mexican",
    rating: 4.0,
    deliveryTime: "22 mins",
    priceRange: "₹500 for two",
    location: "Hyderabad",
    status: "Closed",
    image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=400&h=250&q=80"
  }
];

export const restaurantCategories = [
  "All",
  "South Indian",
  "North Indian",
  "Fast Food",
  "Japanese",
  "Mexican",
  "Chinese",
  "Dessert"
];
