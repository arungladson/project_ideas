import { createSlice } from "@reduxjs/toolkit";

const resturantSlice = createSlice({
    name: "resturant",
    initialState: {
        items: [],
        loading: false,
    },
    reducers: {
        addResturant: (state, action) => {
            state.items.push(action.payload);
        },
    },
});

// export actions
export const { addResturant } = resturantSlice.actions;

// 🔥 THIS LINE IS REQUIRED
export default resturantSlice.reducer;
