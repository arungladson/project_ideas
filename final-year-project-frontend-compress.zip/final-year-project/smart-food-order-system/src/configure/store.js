import { configureStore } from "@reduxjs/toolkit";
import menuReducer from "./order/menuSlice";
import resturantReducer from "./resturant/resturantSlice";
import categoryReducer from "./category/categorySlice";

export const store = configureStore({
  reducer: {
    menu: menuReducer,
    resturant: resturantReducer,
    category: categoryReducer,
  },
});

export default store;
