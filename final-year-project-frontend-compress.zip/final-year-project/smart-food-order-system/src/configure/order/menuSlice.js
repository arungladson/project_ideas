import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// 🔗 Backend URL
const API_URL = "https://localhost:7010/api/Menu";

// ✅ GET MENU
export const fetchMenu = createAsyncThunk(
  'menu/fetchMenu',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(API_URL);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);

// ✅ ADD MENU
export const addMenu = createAsyncThunk(
  'menu/addMenu',
  async (menuItem, { rejectWithValue }) => {
    try {
      const response = await axios.post(API_URL, menuItem);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);

// ✅ UPDATE MENU
export const updateMenu = createAsyncThunk(
  'menu/updateMenu',
  async ({ id, ...menuItem }, { rejectWithValue }) => {
    try {
      const response = await axios.put(`${API_URL}/${id}`, { id, ...menuItem });
      // The API returns NoContent (204) usually for PUT, so we return the updated item
      return response.status === 204 ? { id, ...menuItem } : response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);

// ✅ DELETE MENU
export const deleteMenu = createAsyncThunk(
  'menu/deleteMenu',
  async (id, { rejectWithValue }) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      return id;
    } catch (err) {
      return rejectWithValue(err.response?.data || err.message);
    }
  }
);

// 🔥 SLICE
const menuSlice = createSlice({
  name: 'menu',
  initialState: {
    items: [],
    loading: false,
    error: null
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      // 🔹 FETCH
      .addCase(fetchMenu.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchMenu.fulfilled, (state, action) => {
        state.loading = false;
        state.items = action.payload;
      })
      .addCase(fetchMenu.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      // 🔹 ADD
      .addCase(addMenu.fulfilled, (state, action) => {
        state.items.push(action.payload);
      })

      // 🔹 UPDATE
      .addCase(updateMenu.fulfilled, (state, action) => {
        const index = state.items.findIndex(i => i.id === action.payload.id);
        if (index !== -1) {
          state.items[index] = action.payload;
        }
      })

      // 🔹 DELETE
      .addCase(deleteMenu.fulfilled, (state, action) => {
        state.items = state.items.filter(i => i.id !== action.payload);
      });
  }
});

export default menuSlice.reducer;

