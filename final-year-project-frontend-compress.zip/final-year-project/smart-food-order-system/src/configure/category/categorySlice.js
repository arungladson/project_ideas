import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

const API_URL = "https://localhost:7010/api/Category";

// Helper to normalize category object
const normalizeCategory = (cat) => ({
    id: cat.id || cat.Id,
    name: cat.categoryname || cat.Name || cat.name
});

export const fetchCategory = createAsyncThunk(
    'Category/fetchCategory',
    async (_, { rejectWithValue }) => {
        try {
            const res = await fetch(API_URL);
            if (!res.ok) throw new Error("Failed to fetch categories");
            const data = await res.json();
            return (data || []).map(normalizeCategory);
        } catch (err) {
            return rejectWithValue(err.message);
        }
    }
);

export const addCategory = createAsyncThunk(
    'Category/addCategory',
    async (category, { rejectWithValue }) => {
        try {
            const res = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ categoryname: category.name })
            });
            if (!res.ok) {
                const errorData = await res.text();
                throw new Error(errorData || "Failed to add category");
            }
            const data = await res.json();
            return normalizeCategory(data);
        } catch (err) {
            return rejectWithValue(err.message);
        }
    }
);

export const updateCategory = createAsyncThunk(
    'Category/updateCategory',
    async ({ id, name }, { rejectWithValue }) => {
        try {
            const res = await fetch(`${API_URL}/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id, categoryname: name })
            });
            if (!res.ok) throw new Error("Failed to update category");
            return { id, name };
        } catch (err) {
            return rejectWithValue(err.message);
        }
    }
);

export const deleteCategory = createAsyncThunk(
    'Category/deleteCategory',
    async (id, { rejectWithValue }) => {
        try {
            const res = await fetch(`${API_URL}/${id}`, {
                method: 'DELETE'
            });
            if (!res.ok) throw new Error("Failed to delete category");
            return id;
        } catch (err) {
            return rejectWithValue(err.message);
        }
    }
);

const categorySlice = createSlice({
    name: 'category',
    initialState: {
        items: [],
        loading: false,
        error: null
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            // Fetch
            .addCase(fetchCategory.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchCategory.fulfilled, (state, action) => {
                state.loading = false;
                state.items = action.payload;
            })
            .addCase(fetchCategory.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })
            // Add
            .addCase(addCategory.fulfilled, (state, action) => {
                state.items.push(action.payload);
            })
            // Update
            .addCase(updateCategory.fulfilled, (state, action) => {
                const index = state.items.findIndex(item => item.id === action.payload.id);
                if (index !== -1) {
                    state.items[index] = action.payload;
                }
            })
            // Delete
            .addCase(deleteCategory.fulfilled, (state, action) => {
                state.items = state.items.filter(item => item.id !== action.payload);
            });
    }
});

export default categorySlice.reducer;


